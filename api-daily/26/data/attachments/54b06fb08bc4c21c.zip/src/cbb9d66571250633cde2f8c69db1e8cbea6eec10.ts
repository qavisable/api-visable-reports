/**
 * Feature spec: traffic-mesh background reads (BackGroundController + actuator).
 * GET /actuator/health, /background/get/*, /background/findByPlatformAndLanguage.
 * `apiRequest` / `product` come from `fixtures/` (bypass + `.env.stage-{wlw|ep}`).
 * Client returns `{ status, body }`; this file asserts. Needs `TMB_BASE_URL`.
 */
import { expect, test } from '../../../../fixtures';
import { loadPlatformEnv } from '../../../../config/load-platform-env';
import { BackgroundClient } from '../clients/background-client';
import {
  expectBackgroundSuccess,
  expectBackgroundTokenError,
  expectFilterPanelLinks,
  expectHealthUp,
  expectKeywordBlacklistRows,
  expectMaxSalesBottomLinkId,
  expectPlatformLanguageList,
  expectRefreshStatus,
  expectRootCategoryRows,
  expectSalesBottomLinkIds,
  expectShowroomKeywordRows,
} from '../asserts/background-asserts';
import { BACKGROUND_CASES } from '../utils/background-cases';

test(
  'health reports the service and database as UP',
  { tag: ['@wlw', '@ep', '@functional', '@smoke'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getHealth();

    expectHealthUp(res);
  },
);

test(
  'rejects a stale dynamic-token before the controller runs',
  { tag: ['@wlw', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getKeywordBlacklists({ scene: 'showroom' }, 'stale-token-for-autotest');

    expectBackgroundTokenError(res);
  },
);

test(
  'returns keyword blacklist rows with the normalization contract intact',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const background = BACKGROUND_CASES[product];
    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getKeywordBlacklists({ site: background.blacklistSite });
    const data = expectBackgroundSuccess(res);

    expectKeywordBlacklistRows(data, { site: background.blacklistSite });
  },
);

test(
  'filters keyword blacklist rows by scene without changing the row set',
  { tag: ['@wlw', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const all = expectBackgroundSuccess(await client.getKeywordBlacklists());
    const showroom = expectBackgroundSuccess(
      await client.getKeywordBlacklists({ scene: 'showroom' }),
    );

    expectKeywordBlacklistRows(showroom, { scene: 'showroom' });
    const allIds = new Set(all.map((row) => row.id));
    for (const row of showroom) {
      expect(allIds.has(row.id), `scene filter returned id=${row.id} that is absent from the full list`).toBe(
        true,
      );
    }
  },
);

test(
  'returns showroom keywords scoped to the requested domain',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const background = BACKGROUND_CASES[product];
    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getShowroomKeywords({ domain: background.showroomKeywordDomain });

    expectShowroomKeywordRows(expectBackgroundSuccess(res), {
      domain: background.showroomKeywordDomain,
    });
  },
);

test(
  'returns root categories for the product language',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const background = BACKGROUND_CASES[product];
    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getRootCategoryLangList({ language: background.language });

    expectRootCategoryRows(expectBackgroundSuccess(res), { language: background.language });
  },
);

test(
  'returns an array for the platform/language lookup',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const background = BACKGROUND_CASES[product];
    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.findByPlatformAndLanguage({
      platform: background.platform,
      language: background.language,
    });

    expectPlatformLanguageList(res);
  },
);

test(
  'returns sales bottom link ids as an array or null',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getSalesBottomLinkRelationIds();

    expectSalesBottomLinkIds(expectBackgroundSuccess(res));
  },
);

test(
  'reports an idle link-relation refresh session for a domain',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const background = BACKGROUND_CASES[product];
    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getLinkRelationRefreshStatus({ domain: background.statusDomain });

    expectRefreshStatus(expectBackgroundSuccess(res));
  },
);

test(
  'returns the highest sales bottom-link id as an integer or null',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getMaxSalesBottomLinkRelationId();

    expectMaxSalesBottomLinkId(expectBackgroundSuccess(res));
  },
);

test(
  'returns filter-panel links for a site and page path',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const background = BACKGROUND_CASES[product];
    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getFilterPanelLinks({
      site: background.blacklistSite,
      pagePath: '/showroom/cnc',
    });

    expectFilterPanelLinks(expectBackgroundSuccess(res), { site: background.blacklistSite });
  },
);

test(
  'rejects a filter-panel query without page_path',
  { tag: ['@wlw', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const background = BACKGROUND_CASES[product];
    const client = new BackgroundClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getFilterPanelLinks({ site: background.blacklistSite });

    expect(res.status).toBe(400);
    expect(res.body.status).toBe(400);
  },
);
