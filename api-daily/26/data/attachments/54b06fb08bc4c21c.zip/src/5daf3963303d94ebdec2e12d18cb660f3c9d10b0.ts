import { createHash } from 'node:crypto';
import type { APIRequestContext } from '@playwright/test';
import type {
  FilterPanelLinkRow,
  HealthBody,
  KeywordBlacklistRow,
  PlatformLanguageRow,
  RootCategoryRow,
  ShowroomKeywordRow,
  TrafficMeshEnvelope,
  TrafficMeshResponse,
} from '../models/traffic-mesh';

type QueryParams = Record<string, string | number | undefined>;

const TOKEN_SALT = 'V-SEO-DATA';
const TOKEN_WINDOW_SECONDS = 100;

/**
 * `dynamic-token` used by `/background/*` and `/actuator/health`:
 * sha256("V-SEO-DATA" + floor(epochSeconds / 100)).
 * Not the same scheme as the showroom endpoints' md5 `dynamictoken` — different
 * header name, hash and salt; sending the wrong one yields `{"code":403,"msg":"token error"}`.
 */
export function backgroundToken(nowMs = Date.now()): string {
  const bucket = Math.floor(nowMs / 1000 / TOKEN_WINDOW_SECONDS);
  return createHash('sha256').update(`${TOKEN_SALT}${bucket}`).digest('hex');
}

/** Traffic-mesh background HTTP only: returns `{ status, body }`, specs assert. */
export class BackgroundClient {
  constructor(
    private readonly request: APIRequestContext,
    private readonly baseUrl: string,
  ) {}

  private async getJson<T>(
    path: string,
    params: QueryParams = {},
    token: string = backgroundToken(),
  ): Promise<{ status: number; body: T }> {
    const query = Object.fromEntries(
      Object.entries(params)
        .filter(([, value]) => value !== undefined)
        .map(([key, value]) => [key, String(value)]),
    );
    const response = await this.request.get(`${this.baseUrl}${path}`, {
      params: query,
      headers: { 'dynamic-token': token },
      failOnStatusCode: false,
    });
    const text = await response.text();
    try {
      return { status: response.status(), body: JSON.parse(text) as T };
    } catch {
      throw new Error(
        `traffic-mesh background returned non-JSON (HTTP ${response.status()}): ${text.slice(0, 200)}`,
      );
    }
  }

  private getEnvelope<T>(
    path: string,
    params: QueryParams = {},
    token?: string,
  ): Promise<TrafficMeshResponse<T>> {
    return this.getJson<TrafficMeshEnvelope<T>>(path, params, token);
  }

  /** GET /actuator/health — plain Spring Actuator body, not the envelope. */
  getHealth() {
    return this.getJson<HealthBody>('/actuator/health');
  }

  /** GET /background/get/keywordblacklists — returns the full list; `scene` / `site` are the only filters. */
  getKeywordBlacklists(
    params: { scene?: string; site?: string } = {},
    token?: string,
  ): Promise<TrafficMeshResponse<KeywordBlacklistRow[]>> {
    return this.getEnvelope<KeywordBlacklistRow[]>('/background/get/keywordblacklists', params, token);
  }

  /** GET /background/get/showroomkeyword — server caps the result at 100 rows. */
  getShowroomKeywords(params: {
    domain: string;
    keyword?: string;
    normalizeKeyword?: string;
  }): Promise<TrafficMeshResponse<ShowroomKeywordRow[]>> {
    return this.getEnvelope<ShowroomKeywordRow[]>('/background/get/showroomkeyword', params);
  }

  /** GET /background/get/rootCategoryLangList — root categories for one language. */
  getRootCategoryLangList(params: { language: string }): Promise<
    TrafficMeshResponse<RootCategoryRow[]>
  > {
    return this.getEnvelope<RootCategoryRow[]>('/background/get/rootCategoryLangList', params);
  }

  /** GET /background/findByPlatformAndLanguage — public and envelope-less: the body is a bare array. */
  findByPlatformAndLanguage(params: {
    platform: string;
    language: string;
  }): Promise<{ status: number; body: PlatformLanguageRow[] }> {
    return this.getJson<PlatformLanguageRow[]>('/background/findByPlatformAndLanguage', params);
  }

  /** GET /background/get/salesbottomlinkrelationids — `null` when the table has no rows. */
  getSalesBottomLinkRelationIds(): Promise<TrafficMeshResponse<number[] | null>> {
    return this.getEnvelope<number[] | null>('/background/get/salesbottomlinkrelationids');
  }

  /** GET /background/get/maxsalesbottomlinkrelationid — highest sales bottom-link id, `null` when empty. */
  getMaxSalesBottomLinkRelationId(): Promise<TrafficMeshResponse<number | null>> {
    return this.getEnvelope<number | null>('/background/get/maxsalesbottomlinkrelationid');
  }

  /** GET /background/filter-panel-links — rows for a site and page path; `page_path` is required by the API. */
  getFilterPanelLinks(params: {
    site: string;
    pagePath?: string;
    token?: string;
  }): Promise<TrafficMeshResponse<FilterPanelLinkRow[]>> {
    return this.getEnvelope<FilterPanelLinkRow[]>(
      '/background/filter-panel-links',
      { site: params.site, page_path: params.pagePath },
      params.token,
    );
  }

  /** GET /background/linkrelations/refresh/status — `{ session: ... }`, session is null when idle. */
  getLinkRelationRefreshStatus(params: {
    domain: string;
  }): Promise<TrafficMeshResponse<{ session?: unknown }>> {
    return this.getEnvelope<{ session?: unknown }>('/background/linkrelations/refresh/status', params);
  }
}
