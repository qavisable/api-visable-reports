import type { APIRequestContext } from '@playwright/test';
import type {
  BsMixData,
  BsSummary,
  TrafficMeshEnvelope,
  TrafficMeshResponse,
} from '../models/traffic-mesh';

type QueryParams = Record<string, string | number | undefined>;

/**
 * Traffic-mesh SEO element reads (`/seodata/*`). Public SSR endpoints — no
 * `dynamictoken` / `dynamic-token` header is required, unlike showroom and background.
 */
export class SeoElementClient {
  constructor(
    private readonly request: APIRequestContext,
    private readonly baseUrl: string,
  ) {}

  private async get<T>(
    path: string,
    params: QueryParams = {},
  ): Promise<TrafficMeshResponse<T>> {
    const query = Object.fromEntries(
      Object.entries(params)
        .filter(([, value]) => value !== undefined)
        .map(([key, value]) => [key, String(value)]),
    );
    const response = await this.request.get(`${this.baseUrl}${path}`, {
      params: query,
      failOnStatusCode: false,
    });
    const text = await response.text();
    try {
      return { status: response.status(), body: JSON.parse(text) as TrafficMeshEnvelope<T> };
    } catch {
      throw new Error(
        `traffic-mesh seodata returned non-JSON (HTTP ${response.status()}): ${text.slice(0, 200)}`,
      );
    }
  }

  /** GET /seodata/bs/all — business-sector summary index for one language. */
  async getBsAll(params: { language: string }) {
    return this.get<BsSummary>('/seodata/bs/all', params);
  }

  /**
   * GET /seodata/bs/mixdata/{bsSlug} or /seodata/bs/mixdata/{bsParent}/{bsSlug}.
   * Both path variables are the last segment(s) of the `/bs/...` landing URL.
   */
  async getBsMixData(params: { slug: string; parent?: string; language: string }) {
    const path = params.parent
      ? `/seodata/bs/mixdata/${encodeURIComponent(params.parent)}/${encodeURIComponent(params.slug)}`
      : `/seodata/bs/mixdata/${encodeURIComponent(params.slug)}`;
    return this.get<BsMixData>(path, { language: params.language });
  }
}
