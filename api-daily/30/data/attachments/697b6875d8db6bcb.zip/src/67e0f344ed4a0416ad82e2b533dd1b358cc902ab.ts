/**
 * Feature spec: traffic-mesh business-sector (/seodata/bs/*) landing data.
 * GET /seodata/bs/all and GET /seodata/bs/mixdata/{bsSlug}[/{bsParent}].
 * Public SSR reads (`SeoElementController`) — no dynamic token required.
 * `apiRequest` / `product` come from `fixtures/`. Needs `TMB_BASE_URL`.
 */
import { expect, test } from '../../../../fixtures';
import { loadPlatformEnv } from '../../../../config/load-platform-env';
import { SeoElementClient } from '../clients/seo-element-client';
import {
  expectBsDataNotFound,
  expectBsMixData,
  expectBsSummary,
  expectSeoSuccess,
} from '../asserts/seo-element-asserts';
import { SEO_CASES } from '../utils/seo-cases';
import { stepified } from '../../../../fixtures/stepified';

function lastSegment(url: string): string {
  return (url.split('/').filter(Boolean).pop() ?? '').trim();
}

test(
  'returns the business-sector summary index for the site language',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = stepified(new SeoElementClient(apiRequest, tmbBaseUrl as string));
    const res = await client.getBsAll({ language: SEO_CASES[product].language });

    expectBsSummary(expectSeoSuccess(res));
  },
);

test(
  'returns sector landing data with a breadcrumb rooted at /bs',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = stepified(new SeoElementClient(apiRequest, tmbBaseUrl as string));
    const language = SEO_CASES[product].language;
    const [sector] = expectBsSummary(expectSeoSuccess(await client.getBsAll({ language })));

    const res = await client.getBsMixData({ slug: lastSegment(sector.url), language });

    expectBsMixData(expectSeoSuccess(res), { title: sector.title, depth: 1 });
  },
);

test(
  'returns nested sector landing data for a two-level path',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = stepified(new SeoElementClient(apiRequest, tmbBaseUrl as string));
    const language = SEO_CASES[product].language;
    const [sector] = expectBsSummary(expectSeoSuccess(await client.getBsAll({ language })));
    const child = sector.subList?.[0];
    if (!child) {
      test.skip(true, 'summary index exposes no nested business sector on this site');
      return;
    }

    const res = await client.getBsMixData({
      parent: lastSegment(sector.url),
      slug: lastSegment(child.url),
      language,
    });

    expectBsMixData(expectSeoSuccess(res), { title: child.name, depth: 2 });
  },
);

test(
  'answers DATA NOT FOUND for an unknown sector slug',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = stepified(new SeoElementClient(apiRequest, tmbBaseUrl as string));
    const res = await client.getBsMixData({
      slug: 'autotest-not-a-sector',
      language: SEO_CASES[product].language,
    });

    expectBsDataNotFound(res);
  },
);

test(
  'returns a per-language index, not the fallback language',
  { tag: ['@wlw', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const client = stepified(new SeoElementClient(apiRequest, tmbBaseUrl as string));
    const de = expectBsSummary(expectSeoSuccess(await client.getBsAll({ language: 'de' })));
    const en = expectBsSummary(expectSeoSuccess(await client.getBsAll({ language: 'en' })));

    expect(de[0].title).not.toBe(en[0].title);
    expect(en[0].title).toMatch(/^[A-Za-z][A-Za-z\s-]+$/);
  },
);
