import { createHash } from 'node:crypto';
import type { APIRequestContext } from '@playwright/test';
import type { TmbResponse } from '../models/tmb';

/**
 * TMB (traffic-mesh) HTTP only. Returns `{ status, body }`; specs assert.
 * Headers mirror the Java `GetHeaders` helper: `dynamictoken` = md5("VSEO" + 100s time bucket).
 */
export class TmbClient {
  constructor(
    private readonly request: APIRequestContext,
    private readonly baseUrl: string,
  ) {}

  private tmbHeaders(): Record<string, string> {
    const bucket = Math.floor(Date.now() / 100_000);
    return {
      'Content-Type': 'application/json',
      dynamictoken: createHash('md5').update(`VSEO${bucket}`).digest('hex'),
      website: 'wlw.de',
      Authorization: 'Bearer eyJ0eXAiOiJKV1QiLCJhb',
    };
  }

  private async get(
    path: string,
    params: Record<string, string | undefined>,
  ): Promise<{ status: number; body: TmbResponse }> {
    const query = Object.fromEntries(
      Object.entries(params).filter(([, value]) => value !== undefined),
    ) as Record<string, string>;
    const response = await this.request.get(`${this.baseUrl}${path}`, {
      params: query,
      headers: this.tmbHeaders(),
      failOnStatusCode: false,
    });
    const text = await response.text();
    try {
      return { status: response.status(), body: JSON.parse(text) as TmbResponse };
    } catch {
      throw new Error(`TMB returned non-JSON (HTTP ${response.status()}): ${text.slice(0, 200)}`);
    }
  }

  /** GET seodata/getAllElementsByUrl. `host` / `language` optional (null in the Java data). */
  async getAllElementsByUrl(params: { host?: string; language?: string; url: string }) {
    return this.get('/seodata/getAllElementsByUrl', params);
  }

  /** GET seodata/bd/skwd. */
  async skwd(params: { letter: string; host: string; language: string; url: string }) {
    return this.get('/seodata/bd/skwd', params);
  }

  /** GET seodata/bd/skwd/all. */
  async skwdAll(params: { host: string; language: string; url: string }) {
    return this.get('/seodata/bd/skwd/all', params);
  }

  /** GET api/v1/page-elements/get. */
  async pageElementsGet(params: { domain: string; urlPath: string; language: string }) {
    return this.get('/api/v1/page-elements/get', params);
  }

  /** GET api/v1/psearch-proxy/search. Wire keys keep the endpoint's snake_case. */
  async psearchProxySearch(params: {
    lang: string;
    query: string;
    site: string;
    country: string;
    site_code: string;
    top_level_domain: string;
    ufs_session_id: string;
    history: string;
    seoURL: string;
    countrySlugTitle: string;
  }) {
    return this.get('/api/v1/psearch-proxy/search', params);
  }
}
