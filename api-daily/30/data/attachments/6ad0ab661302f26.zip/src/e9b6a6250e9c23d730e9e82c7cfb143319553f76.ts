/**
 * Feature spec: TMB (traffic-mesh) SEO endpoints — port of the TestNG `SEOElementsAPITest`.
 * `apiRequest` / `product` come from `fixtures/` (bypass + `.env.stage-{wlw|ep}`).
 * Client returns `{ status, body }`; this file asserts. Needs `TMB_BASE_URL` in `.env.stage-wlw`.
 */
import { expect, test } from '../../../../fixtures';
import { loadPlatformEnv } from '../../../../config/load-platform-env';
import { TmbClient } from '../clients/tmb-client';
import {
  expectKeywordSuggestionsPayload,
  expectNonEmptyBusinessValue,
  expectTmbDataMap,
  expectTmbFunctionalPayload,
  hasAnyKey,
} from '../asserts/tmb-asserts';
import { stepified } from '../../../../fixtures/stepified';

test('wlw showroom URL returns SEO elements from getAllElementsByUrl', { tag: ['@wlw', '@functional', '@regression'] }, async ({
  apiRequest,
  product,
}) => {
  const { tmbBaseUrl } = loadPlatformEnv(product);
  test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

  const tmb = stepified(new TmbClient(apiRequest, tmbBaseUrl as string));
  const res = await tmb.getAllElementsByUrl({ url: 'https://www.wlw.de/showroom/cnc' });

  expect(res.status).toBe(200);
  expectTmbFunctionalPayload(res.body, 200, true, true);
  const data = expectTmbDataMap(res.body);
  expect(
    hasAnyKey(data, [
      'title',
      'metaTitle',
      'metaDescription',
      'canonical',
      'h1',
      'elements',
      'pageElements',
      'findQuotesForName',
      'internalLinks',
      'internalLinkViews',
    ]),
    'SEO elements response should expose at least one core SEO business field',
  ).toBe(true);
});

test('europages host returns keyword suggestions from skwd', { tag: ['@wlw', '@functional', '@regression', '@quarantine'] }, async ({
  apiRequest,
  product,
}) => {
  const { tmbBaseUrl } = loadPlatformEnv(product);
  test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);
  test.skip(
    true,
    'Endpoint retired: /seodata/bd/skwd has no handler on traffic-mesh-backend@main (verified 2026-11-06 in source); kept as a sentinel for a possible restore.',
  );

  const tmb = stepified(new TmbClient(apiRequest, tmbBaseUrl as string));
  const res = await tmb.skwd({
    letter: 'A-1',
    host: 'https://www.europages.co.uk',
    language: 'en',
    url: 'https://www.europages.co.uk',
  });

  expect(res.status).toBe(200);
  expectTmbFunctionalPayload(res.body, 200, true, true);
  expectKeywordSuggestionsPayload(expectTmbDataMap(res.body));
});

test('europages host returns all keyword suggestions from skwdAll', { tag: ['@wlw', '@functional', '@regression', '@quarantine'] }, async ({
  apiRequest,
  product,
}) => {
  const { tmbBaseUrl } = loadPlatformEnv(product);
  test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);
  test.skip(
    true,
    'Endpoint retired: /seodata/bd/skwd/all has no handler on traffic-mesh-backend@main (verified 2026-11-06 in source); kept as a sentinel for a possible restore.',
  );

  const tmb = stepified(new TmbClient(apiRequest, tmbBaseUrl as string));
  const res = await tmb.skwdAll({
    host: 'https://www.europages.co.uk',
    language: 'en',
    url: 'https://www.europages.co.uk',
  });

  expect(res.status).toBe(200);
  expectTmbFunctionalPayload(res.body, 200, true, true);
  expectKeywordSuggestionsPayload(expectTmbDataMap(res.body));
});

test('wlw domain returns page elements from page-elements/get', { tag: ['@wlw', '@functional', '@regression'] }, async ({
  apiRequest,
  product,
}) => {
  const { tmbBaseUrl } = loadPlatformEnv(product);
  test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

  const tmb = stepified(new TmbClient(apiRequest, tmbBaseUrl as string));
  const res = await tmb.pageElementsGet({
    domain: 'https://www.wlw.de',
    urlPath: '/de/showroom/cnc',
    language: 'de',
  });

  expect(res.status).toBe(200);
  expectTmbFunctionalPayload(res.body, 200, true, true);
  const data = expectTmbDataMap(res.body);
  expect(
    hasAnyKey(data, [
      'pageElements',
      'elements',
      'title',
      'metaDescription',
      'h1',
      'canonical',
      'metaTitle',
      'findQuotesForName',
      'internalLinkViews',
    ]),
    'page-elements endpoint should return page element business payload',
  ).toBe(true);
});

test('psearch-proxy search returns search business fields for a french query', { tag: ['@wlw', '@functional', '@regression'] }, async ({
  apiRequest,
  product,
}) => {
  const { tmbBaseUrl } = loadPlatformEnv(product);
  test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

  const tmb = stepified(new TmbClient(apiRequest, tmbBaseUrl as string));
  const res = await tmb.psearchProxySearch({
    lang: 'fr',
    query: '%C3%A0%20base%20de%20v%C3%A9g%C3%A9taux%20stabilis%C3%A9s%20et%20de%20fleurs%20press%C3%A9es',
    site: 'ep',
    country: 'FR',
    site_code: 'FR',
    top_level_domain: 'fr',
    ufs_session_id: '611ead3fd9fdeb5a',
    history: 'false',
    seoURL:
      'https%3A%2F%2Fwww.europages-staging.fr%2Fentreprises%2F%C3%A0%20base%20de%20v%C3%A9g%C3%A9taux%20stabilis%C3%A9s%20et%20de%20fleurs%20press%C3%A9es.html',
    countrySlugTitle: 'belgium',
  });

  expect(res.status).toBe(200);
  expectTmbFunctionalPayload(res.body, 200, null, false);
  const data = expectTmbDataMap(res.body);
  expect(
    hasAnyKey(data, ['returnCount', 'results', 'items', 'list', 'data', 'companies', 'engineTime']),
    'search endpoint should return search business fields',
  ).toBe(true);

  if (typeof data.returnCount === 'number') {
    expect(data.returnCount, 'returnCount should be non-negative').toBeGreaterThanOrEqual(0);
    if (data.returnCount > 0) {
      if ('results' in data) {
        expectNonEmptyBusinessValue(data.results, 'results');
      } else if ('items' in data) {
        expectNonEmptyBusinessValue(data.items, 'items');
      } else if ('list' in data) {
        expectNonEmptyBusinessValue(data.list, 'list');
      } else if ('companies' in data) {
        expectNonEmptyBusinessValue(data.companies, 'companies');
      }
    }
  }
});
