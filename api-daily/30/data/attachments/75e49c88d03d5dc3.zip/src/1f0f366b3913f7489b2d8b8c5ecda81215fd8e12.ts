/**
 * Feature spec: traffic-mesh category landing page.
 * GET /showroom-cate/data — `seo-category-controller#getSeoCate`.
 * `apiRequest` / `product` come from `fixtures/` (bypass + `.env.stage-{wlw|ep}`).
 * Client returns `{ status, body }`; this file asserts. Needs `TMB_BASE_URL`.
 */
import { expect, test } from '../../../../fixtures';
import { loadPlatformEnv } from '../../../../config/load-platform-env';
import { TrafficMeshClient } from '../clients/traffic-mesh-client';
import {
  expectSeoCategoryLeafPage,
  expectSeoCategoryPage,
  expectSpringBadRequest,
  expectTrafficMeshBusinessError,
} from '../asserts/traffic-mesh-asserts';
import { SHOWROOM_CASES } from '../utils/showroom-cases';
import { stepified } from '../../../../fixtures/stepified';

test(
  'returns the root landing page for a known category slug',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = stepified(new TrafficMeshClient(apiRequest, tmbBaseUrl as string));
    const res = await client.getSeoCate(
      {
        category: showroom.slug,
        version: 'cate_re',
        platform: showroom.platform,
        site_code: showroom.siteCode,
      },
      showroom,
    );

    expectSeoCategoryPage(res, {
      name: showroom.categoryName,
      id: showroom.categoryId,
      slug: showroom.slug,
    });
  },
);

test(
  'returns a leaf landing page with its parent breadcrumb',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = stepified(new TrafficMeshClient(apiRequest, tmbBaseUrl as string));
    const res = await client.getSeoCate(
      {
        category: showroom.childSlug,
        version: 'cate_re',
        platform: showroom.platform,
        site_code: showroom.siteCode,
      },
      showroom,
    );

    expectSeoCategoryLeafPage(res, {
      parentId: showroom.categoryId,
      childId: showroom.childId,
      childName: showroom.childName,
    });
  },
);

test(
  'returns LANDING PAGE NOT EXIST for an unknown category slug',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = stepified(new TrafficMeshClient(apiRequest, tmbBaseUrl as string));
    const res = await client.getSeoCate(
      {
        category: 'not-a-real-showroom-cate-999999',
        version: 'cate_re',
        platform: showroom.platform,
        site_code: showroom.siteCode,
      },
      showroom,
    );

    expectTrafficMeshBusinessError(res, 302, 'LANDING PAGE NOT EXIST');
  },
);

test(
  'rejects a request without the mandatory version parameter',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = stepified(new TrafficMeshClient(apiRequest, tmbBaseUrl as string));
    const res = await client.getSeoCate(
      { category: showroom.slug, platform: showroom.platform, site_code: showroom.siteCode },
      showroom,
    );

    expectTrafficMeshBusinessError(res, 400, 'parameter error');
  },
);

test(
  'rejects a request without the required category parameter',
  { tag: ['@wlw', '@ep', '@functional', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = stepified(new TrafficMeshClient(apiRequest, tmbBaseUrl as string));
    const res = await client.getSeoCate(
      { version: 'cate_re', platform: showroom.platform, site_code: showroom.siteCode },
      showroom,
    );

    expectSpringBadRequest(res);
    expect(res.body.code, 'Spring 400 must not carry a business envelope code').toBeUndefined();
  },
);
