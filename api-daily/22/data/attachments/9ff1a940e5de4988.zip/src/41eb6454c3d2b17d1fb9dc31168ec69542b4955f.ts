/**
 * Feature spec: traffic-mesh showroom keyword endpoints.
 * GET /showroom/v1/crumbs and GET /showroom/static/data — `Showroom API`.
 * `apiRequest` / `product` come from `fixtures/` (bypass + `.env.stage-{wlw|ep}`).
 * Client returns `{ status, body }`; this file asserts. Needs `TMB_BASE_URL`.
 */
import { expect, test } from '../../../../fixtures';
import { loadPlatformEnv } from '../../../../config/load-platform-env';
import { TrafficMeshClient } from '../clients/traffic-mesh-client';
import {
  expectCrumbs,
  expectEmptyShowroomStaticPage,
  expectShowroomStaticPage,
  expectSpringBadRequest,
  expectTrafficMeshBusinessError,
  expectTrafficMeshSuccess,
} from '../asserts/traffic-mesh-asserts';
import { SHOWROOM_CASES } from '../utils/showroom-cases';

const UFS_SESSION_ID = 'autotest-showroom-session';

test(
  'returns the category breadcrumb for a keyword',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getCrumbs(
      { keyword: showroom.keyword, siteId: showroom.siteId },
      showroom,
    );

    expectCrumbs(res, { language: showroom.language });
  },
);

test(
  'returns a null breadcrumb payload for an empty keyword',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getCrumbs({ keyword: '', siteId: showroom.siteId }, showroom);

    const data = expectTrafficMeshSuccess(res);
    expect(data.crumbs).toBeNull();
  },
);

test(
  'rejects a breadcrumb request without siteId',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getCrumbs({ keyword: showroom.keyword }, showroom);

    expectSpringBadRequest(res);
  },
);

test(
  'returns a static showroom page with consistent paging',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getShowroomStaticData(
      {
        q: showroom.keyword,
        ufsSessionId: UFS_SESSION_ID,
        platform: showroom.platform,
        siteCode: showroom.siteCode,
      },
      showroom,
    );

    expectShowroomStaticPage(res, { query: showroom.keyword, page: 1, pageSize: 30 });
  },
);

test(
  'returns a null breadcrumb payload for an unsupported language',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getCrumbs(
      { keyword: showroom.keyword, siteId: showroom.siteId },
      { ...showroom, language: 'xx' },
    );

    const data = expectTrafficMeshSuccess(res);
    expect(data.crumbs).toBeNull();
  },
);

test(
  'honours the requested static page and page size',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getShowroomStaticData(
      {
        q: showroom.keyword,
        ufsSessionId: UFS_SESSION_ID,
        platform: showroom.platform,
        siteCode: showroom.siteCode,
        page: 2,
        perPage: 5,
      },
      showroom,
    );

    expectShowroomStaticPage(res, { query: showroom.keyword, page: 2, pageSize: 5 });
  },
);

test(
  'returns Query keyword is empty for a static request without q',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getShowroomStaticData(
      {
        ufsSessionId: UFS_SESSION_ID,
        platform: showroom.platform,
        siteCode: showroom.siteCode,
      },
      showroom,
    );

    expectTrafficMeshBusinessError(res, 302, 'Query keyword is empty');
  },
);

test(
  'normalises page=0 to the first static page',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getShowroomStaticData(
      {
        q: showroom.keyword,
        ufsSessionId: UFS_SESSION_ID,
        platform: showroom.platform,
        siteCode: showroom.siteCode,
        page: 0,
        perPage: 5,
      },
      showroom,
    );

    expectShowroomStaticPage(res, { query: showroom.keyword, page: 1, pageSize: 5 });
  },
);

test(
  'honours a 100-item static page size',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getShowroomStaticData(
      {
        q: showroom.keyword,
        ufsSessionId: UFS_SESSION_ID,
        platform: showroom.platform,
        siteCode: showroom.siteCode,
        perPage: 100,
      },
      showroom,
    );

    expectShowroomStaticPage(res, { query: showroom.keyword, page: 1, pageSize: 100 });
  },
);

test(
  'returns an empty static page beyond the last page',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getShowroomStaticData(
      {
        q: showroom.keyword,
        ufsSessionId: UFS_SESSION_ID,
        platform: showroom.platform,
        siteCode: showroom.siteCode,
        page: 9999,
        perPage: 5,
      },
      showroom,
    );

    expectEmptyShowroomStaticPage(res);
  },
);

test(
  'returns an empty static page for a non-numeric page size',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getShowroomStaticData(
      {
        q: showroom.keyword,
        ufsSessionId: UFS_SESSION_ID,
        platform: showroom.platform,
        siteCode: showroom.siteCode,
        perPage: 'abc',
      },
      showroom,
    );

    expectEmptyShowroomStaticPage(res);
  },
);

test(
  'returns an empty static page without a session id',
  { tag: ['@wlw', '@ep', '@regression'] },
  async ({ apiRequest, product }) => {
    const { tmbBaseUrl } = loadPlatformEnv(product);
    test.skip(!tmbBaseUrl, `TMB_BASE_URL missing in .env.stage-${product}`);

    const showroom = SHOWROOM_CASES[product];
    const client = new TrafficMeshClient(apiRequest, tmbBaseUrl as string);
    const res = await client.getShowroomStaticData(
      {
        q: showroom.keyword,
        platform: showroom.platform,
        siteCode: showroom.siteCode,
      },
      showroom,
    );

    expectEmptyShowroomStaticPage(res);
  },
);
