import { createHash } from 'node:crypto';
import type { APIRequestContext } from '@playwright/test';
import type {
  CrumbsData,
  SeoCategoryData,
  ShowroomStaticData,
  TrafficMeshResponse,
} from '../models/traffic-mesh';

type QueryParams = Record<string, string | number | boolean | undefined>;

/**
 * Per-request context. `host` is the product host the landing page is resolved for
 * (wlw needs it together with `Accept-Language`); `language` is sent both as the
 * `Accept-Language` header and as the query param the controller expects.
 */
export type TrafficMeshContext = {
  host: string;
  language: string;
};

/**
 * Traffic-mesh showroom HTTP only: returns `{ status, body }`, specs assert.
 * `dynamictoken` mirrors the Java `GetHeaders` helper (md5 of "VSEO" + 100s bucket).
 */
export class TrafficMeshClient {
  constructor(
    private readonly request: APIRequestContext,
    private readonly baseUrl: string,
  ) {}

  private headers(ctx: TrafficMeshContext): Record<string, string> {
    const bucket = Math.floor(Date.now() / 100_000);
    return {
      'Content-Type': 'application/json',
      dynamictoken: createHash('md5').update(`VSEO${bucket}`).digest('hex'),
      'Accept-Language': ctx.language,
      'X-Application-Id': 'homepage-frontend',
      'x-host': ctx.host,
    };
  }

  private async get<T>(
    path: string,
    params: QueryParams,
    ctx: TrafficMeshContext,
  ): Promise<TrafficMeshResponse<T>> {
    const query = Object.fromEntries(
      Object.entries(params)
        .filter(([, value]) => value !== undefined)
        .map(([key, value]) => [key, String(value)]),
    );
    const response = await this.request.get(`${this.baseUrl}${path}`, {
      params: query,
      headers: this.headers(ctx),
      failOnStatusCode: false,
    });
    const text = await response.text();
    try {
      return { status: response.status(), body: JSON.parse(text) };
    } catch {
      throw new Error(
        `traffic-mesh returned non-JSON (HTTP ${response.status()}): ${text.slice(0, 200)}`,
      );
    }
  }

  /**
   * GET /showroom-cate/data (`seo-category-controller#getSeoCate`).
   * `category` is the landing-page slug (`elektrotechnik-100038`) and `version`
   * is mandatory at runtime even though Swagger does not mark it required.
   */
  getSeoCate(
    params: {
      category?: string;
      version?: string;
      platform: string;
      site_code?: string;
      page?: number;
      per_page?: number;
      source?: string;
    },
    ctx: TrafficMeshContext,
  ) {
    return this.get<SeoCategoryData>(
      '/showroom-cate/data',
      { ...params, language: ctx.language },
      ctx,
    );
  }

  /** GET /showroom/v1/crumbs (`Showroom API#getSeoDataCrumbs`). */
  getCrumbs(
    params: {
      keyword: string;
      /** Required by the API; optional here so the contract spec can omit it. */
      siteId?: string;
      bot?: boolean;
      tld?: string;
    },
    ctx: TrafficMeshContext,
  ) {
    return this.get<CrumbsData>(
      '/showroom/v1/crumbs',
      { ...params, language: ctx.language },
      ctx,
    );
  }

  /** GET /showroom/static/data (`Showroom API#getShowroomStaticData`). */
  getShowroomStaticData(
    params: {
      q?: string;
      ufsSessionId?: string;
      platform: string;
      siteCode?: string;
      /** Strings allowed so the contract specs can send invalid values. */
      page?: number | string;
      perPage?: number | string;
      urlPath?: string;
    },
    ctx: TrafficMeshContext,
  ) {
    return this.get<ShowroomStaticData>(
      '/showroom/static/data',
      { ...params, language: ctx.language },
      ctx,
    );
  }
}
