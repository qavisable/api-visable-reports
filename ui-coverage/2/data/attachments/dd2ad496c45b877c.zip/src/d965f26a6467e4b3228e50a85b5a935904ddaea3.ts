/**
 * Qase VISABLE 2:79:143 (REG-MA-02): change preferred language, Save, reload — selection persists.
 */
import { test } from '../../../fixtures';
import { hasBuyerCredentials } from '../../../config/load-platform-env';
import {
  alternatePreferredLanguageLabel,
  myAccountExpectations,
  preferredLanguageOptionFromDisplay,
} from '../../../config/my-account';
import { openMyAccountSettingsAsBuyer } from '../../flows/open-my-account-settings.flow';
import { MyAccountPage } from '../../pages/user-account/my-account.page';

test.describe('My Account preferred language persistence (Qase 2:79:143)', () => {
  let restorePreferredLanguage: (() => Promise<void>) | undefined;

  test.beforeEach(async ({ publicPage, product, apiRequest }) => {
    restorePreferredLanguage = undefined;
    test.skip(
      !hasBuyerCredentials(product),
      `BUYER_EMAIL / BUYER_PASSWORD missing in .env.stage-${product}`,
    );
    test.setTimeout(120_000);
    await openMyAccountSettingsAsBuyer(publicPage, product, apiRequest);
  });

  test.afterEach(async () => {
    const restore = restorePreferredLanguage;
    restorePreferredLanguage = undefined;
    if (!restore) return;
    try {
      await restore();
    } catch (restoreError) {
      console.warn('Failed to restore BUYER_* preferred language:', restoreError);
    }
  });

  test('preferred language persists after Save and reload', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
    product,
  }) => {
    const locale = myAccountExpectations(product);
    const myAccount = new MyAccountPage(publicPage);

    await myAccount.scrollToLanguageSection();
    await myAccount.expectLanguageSection(locale.languageSection);

    const originalDisplay = await myAccount.preferredLanguageLabel();
    const originalOption = preferredLanguageOptionFromDisplay(originalDisplay);
    const next = alternatePreferredLanguageLabel(originalDisplay);

    await myAccount.selectPreferredLanguage(next);
    await myAccount.clickLanguageSave();

    restorePreferredLanguage = async () => {
      await myAccount.openSettings(locale.settingsLang);
      await myAccount.scrollToLanguageSection();
      const after = preferredLanguageOptionFromDisplay(await myAccount.preferredLanguageLabel());
      if (after !== originalOption) {
        await myAccount.selectPreferredLanguage(originalOption);
        await myAccount.clickLanguageSave();
      }
    };

    await myAccount.openSettings(locale.settingsLang, 'load');
    await myAccount.expectPreferredLanguage(next);
  });
});
