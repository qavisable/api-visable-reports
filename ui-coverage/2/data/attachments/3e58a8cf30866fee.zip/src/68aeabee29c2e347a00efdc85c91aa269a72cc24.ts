import { type Page } from '@playwright/test';
import { expect } from '../../../fixtures/expect';
import { dismissCookieBanner } from '../../../fixtures/staging-traps';
import type { ProductFamily } from '../../../config/platforms';

/** `/en/supplier-registration` — create-account form (user, not supplier). Do not retarget to `/en/registration`. */
export class RegistrationPage {
  constructor(
    private readonly page: Page,
    private readonly product: ProductFamily = 'wlw',
  ) {}

  private firstNameInput() {
    return this.page.locator('input[name="traits.profile_registration.given_name"]');
  }

  private surnameInput() {
    return this.page.locator('input[name="traits.profile_registration.surname"]');
  }

  private phoneCountryButton() {
    return this.page
      .locator('button#_country_dial_code')
      .or(this.page.getByRole('button', { name: /^Country code$/i }));
  }

  private phoneInput() {
    return this.page.locator('#_mobile_phone');
  }

  private emailInput() {
    return this.page.locator('#traits\\.email');
  }

  private passwordInput() {
    return this.page.locator('input[type="password"]');
  }

  private submitButton() {
    return this.page.getByRole('button', { name: /start registration|registrierung starten/i });
  }

  private phoneCountryMenuItem(country: string) {
    return this.page.getByRole('menuitem', { name: new RegExp(`^${country}:\\s*\\+`) });
  }

  private async selectPhoneCountry(country: string): Promise<void> {
    const button = this.phoneCountryButton();
    const option = this.phoneCountryMenuItem(country);

    await expect(button).toBeVisible({ timeout: 15_000 });

    for (let attempt = 0; attempt < 3; attempt += 1) {
      await dismissCookieBanner(this.page);
      await button.click();

      if (await option.isVisible({ timeout: 5_000 }).catch(() => false)) {
        await option.scrollIntoViewIfNeeded();
        await option.click();
        await expect(option).toBeHidden({ timeout: 10_000 });
        return;
      }

      await this.page.keyboard.press('Escape').catch(() => undefined);
    }

    await expect(option).toBeVisible({ timeout: 15_000 });
    await option.scrollIntoViewIfNeeded();
    await option.click();
    await expect(option).toBeHidden({ timeout: 10_000 });
  }

  async open(): Promise<void> {
    await this.page.goto('/en/supplier-registration');
    await dismissCookieBanner(this.page);
  }

  async fillRegistrationForm(input: {
    firstName: string;
    surname: string;
    phoneCountry?: string;
    phone?: string;
    email: string;
    password: string;
  }): Promise<void> {
    await dismissCookieBanner(this.page);
    await this.firstNameInput().fill(input.firstName);
    await this.surnameInput().fill(input.surname);
    if (input.phoneCountry) {
      await this.selectPhoneCountry(input.phoneCountry);
    }
    if (input.phone) {
      await this.phoneInput().fill(input.phone);
    }
    await this.emailInput().fill(input.email);
    await this.passwordInput().fill(input.password);
  }

  async submit(): Promise<void> {
    await dismissCookieBanner(this.page);
    await Promise.all([
      this.page.waitForURL(/\/verification/, { timeout: 90_000 }),
      this.submitButton().click(),
    ]);
  }
}
