/**
 * WORKED EXAMPLE (this file only): end-to-end create-account + Mailtrap OTP.
 *
 * Scenario: a new **user** (not the paid SUPPLIER_* persona from .env) registers on staging,
 * receives a 6-digit code by email, and leaves the /verification step.
 *
 * OTP + Mailtrap polling live **in this spec** on purpose (see ui/AGENTS.md). Full supplier
 * onboard uses a different path (`registerVerifiedUser` in e2e), not a copy of this file.
 *
 * How to read this file top to bottom:
 * 1) Imports load modules once when Playwright loads the file (no browser yet).
 * 2) test(...) **registers** the scenario; the callback body does not run at import time.
 * 3) When the runner executes this test, Playwright prepares fixtures (see fixtures/index.ts)
 *    then calls the callback with { publicPage, product }.
 * 4) Lines inside the callback run in order: env guard → data → UI → Mailtrap API → OTP UI.
 */
import { expect, test } from '../../../fixtures';
// ^ Must import `test` from fixtures/index.ts (not @playwright/test). That `test` is base.extend({
//   product, publicPage, apiRequest }). Only names you list in the callback below are prepared.

import { hasMailtrapEnv, mailtrapSettings } from '../../../config/load-platform-env';
// ^ Reads .env.stage-wlw / .env.stage-ep (which file depends on `product` from the fixture).

import { waitForMailtrapOtp } from '../../../fixtures/mailtrap';
// ^ Plain helper (not a Playwright fixture). HTTP poll of Mailtrap sandbox for the 6-digit code.

import {
  createDisposableRegistrationEmail,
  createDisposableRegistrationPassword,
} from '../../../fixtures/test-data';
// ^ Unique email/password per run so we do not collide with SUPPLIER_EMAIL or prior runs.

import { EmailVerificationPage } from '../../../ui/pages/registration/email-verification.page';
import { RegistrationPage } from '../../../ui/pages/registration/registration.page';
// ^ Page objects: one class per screen; the spec orchestrates them (thin pages, no Mailtrap inside).

// --- Registration (happens at file load; body not executed yet) -----------------
// Playwright records: title, tags, and the async callback. Tags @wlw and @ep match
// playwright.config.ts projects (grep). Same file runs twice if you run both projects.
test('user can create an account and confirm email via Mailtrap OTP', {
  tag: ['@wlw', '@ep', '@regression'],
}, async ({
  // --- Fixture request list (NOT arguments you pass from the terminal) ------------
  // Playwright builds one object and passes it into this function when the test runs.
  // Names must match keys in fixtures/index.ts extend({ product, publicPage, apiRequest }).
  // We only ask for publicPage + product → apiRequest fixture is NOT set up for this test.
  //
  // Order here does NOT control setup order. `product` is always resolved before `publicPage`
  // because publicPage's factory depends on `product` in index.ts.
  publicPage,
  // ^ Same underlying Playwright Page as built-in `page`, but after publicPage fixture setup:
  //   staging bypass already on context (from config), cookie consent, recaptcha stubs
  //   (see fixtures/index.ts → staging-traps.ts). Used for all UI steps below.

  product,
  // ^ 'wlw' | 'ep'. Set in fixtures/index.ts from testInfo.project.name when you run
  //   --project=wlw or --project=ep. Drives .env.stage-{product}, baseURL, and page objects.
}) => {
  // --- First executable lines in the test body (fixtures are already ready) --------

  // Without MAILTRAP_API_TOKEN this scenario cannot pass (we poll Mailtrap at the end).
  // Skip = "not run / missing local secret", not a product failure. See docs/adding-tests.md.
  test.skip(!hasMailtrapEnv(product), `MAILTRAP_API_TOKEN missing in .env.stage-${product}`);

  // Form + email delivery + up to 90s Mailtrap poll need more than the default 120s config timeout.
  test.setTimeout(180_000);

  const mailtrap = mailtrapSettings(product);
  // ^ Safe after hasMailtrapEnv; throws if token missing (should not happen if skip did not fire).

  const email = createDisposableRegistrationEmail();
  // ^ Fresh inbox address each run (test+timestamp@automation.com). Not SUPPLIER_EMAIL.

  const password = createDisposableRegistrationPassword();

  const registrationStartedAt = new Date().toISOString();
  // ^ Mailtrap poll ignores messages older than this (avoids picking OTP from an old test).

  const registration = new RegistrationPage(publicPage, product);
  const verification = new EmailVerificationPage(publicPage, product);
  // ^ Both use the same tab (publicPage) and the same product for URLs / env.

  // --- UI: registration form (gold URL is /en/supplier-registration, not /en/registration) ---
  await registration.open();
  await registration.fillRegistrationForm({
    firstName: 'QA',
    surname: 'Mailtrap',
    phoneCountry: 'Albania',
    phone: '12345678',
    email,
    password,
  });
  await registration.submit();
  // ^ Waits for navigation to a URL containing /verification.

  await verification.expectOtpStep();
  // ^ Asserts six single-digit OTP inputs are visible; does not read email yet.

  // --- Outside the browser: Mailtrap Email Sandbox API (fixtures/mailtrap.ts) ---
  const { otp } = await waitForMailtrapOtp({
    apiToken: mailtrap.apiToken,
    sandboxId: mailtrap.sandboxId,
    toEmail: email,
    subjectHint: 'confirm',
    receivedAfterIso: registrationStartedAt,
    timeoutMs: 90_000,
  });

  await verification.completeOtpVerification(otp);
  // ^ Fills 6 boxes, submits; page object also expects to leave /verification.

  await expect(publicPage).not.toHaveURL(/\/verification/);
  // ^ Spec-level assertion: successful path is no longer on the verification route.
});
