import type { APIRequestContext, BrowserContext } from '@playwright/test';

/** Copy Kratos session cookies from an API client into the browser. Not Playwright `use.storageState` / a setup-project. */
export async function syncApiSessionToBrowser(
  apiRequest: APIRequestContext,
  browserContext: BrowserContext,
): Promise<number> {
  const { cookies } = await apiRequest.storageState();
  if (cookies.length === 0) {
    return 0;
  }
  await browserContext.addCookies(cookies);
  return cookies.length;
}
