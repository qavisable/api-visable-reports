/**
 * Wraps an `APIRequestContext` so every call becomes a step with the request and
 * response attached (URL, headers, body, status, duration). allure-playwright
 * only records browser traffic, so API suites would otherwise have no exchange
 * in the report. Secret-bearing headers are redacted before attaching.
 */
import { test, type APIRequestContext, type APIResponse, type TestInfo } from '@playwright/test';

const HTTP_METHODS = new Set(['get', 'post', 'put', 'patch', 'delete', 'head', 'fetch']);
const SECRET_HEADERS = new Set([
  'authorization',
  'proxy-authorization',
  'cookie',
  'set-cookie',
  'x-visable-bypass-token',
]);
const MAX_BODY = 200_000;

function redact(headers: Record<string, string> | undefined) {
  if (!headers) return undefined;
  return Object.fromEntries(
    Object.entries(headers).map(([name, value]) => [
      name,
      SECRET_HEADERS.has(name.toLowerCase()) || SECRET_KEY.test(name) ? '***' : value,
    ]),
  );
}

function parseBody(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

const SECRET_KEY = /pass(word)?|token|secret|authorization|credential|cookie|session/i;

/** The Allure report is public on GitHub Pages: never publish passwords or tokens. */
function redactJson(value: unknown, depth = 0): unknown {
  if (depth > 8) return value;
  if (Array.isArray(value)) return value.map((item) => redactJson(item, depth + 1));
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([key, item]) => [
        key,
        SECRET_KEY.test(key) ? '***' : redactJson(item, depth + 1),
      ]),
    );
  }
  return value;
}

/** Clients send JSON objects, JSON strings or URL-encoded form bodies; redact all three. */
function redactBody(value: unknown): unknown {
  if (typeof value !== 'string') return redactJson(value);
  const trimmed = value.trim();
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    const parsed = parseBody(trimmed);
    if (typeof parsed !== 'string') return redactJson(parsed);
  }
  if (/^[^=&\s]+=[^&]*(&[^=&\s]+=[^&]*)*$/.test(trimmed)) {
    return Object.fromEntries(
      [...new URLSearchParams(trimmed).entries()].map(([key, item]) => [
        key,
        SECRET_KEY.test(key) ? '***' : item,
      ]),
    );
  }
  return value;
}

function redactUrl(raw: string): string {
  try {
    const url = new URL(raw);
    for (const key of [...url.searchParams.keys()]) {
      if (SECRET_KEY.test(key)) url.searchParams.set(key, '***');
    }
    return url.toString();
  } catch {
    return raw;
  }
}

function shortUrl(url: string): string {
  const path = url.replace(/^https?:\/\/[^/]+/, '');
  return path.length > 120 ? `${path.slice(0, 120)}…` : path;
}

async function attachExchange(
  testInfo: TestInfo,
  method: string,
  options: Record<string, unknown>,
  response: APIResponse,
  startedAt: number,
) {
  const durationMs = Date.now() - startedAt;
  await testInfo.attach('request', {
    contentType: 'application/json',
    body: JSON.stringify(
      {
        method,
        url: redactUrl(response.url()),
        durationMs,
        params: redactJson(options.params),
        headers: redact(options.headers as Record<string, string> | undefined),
        body: redactBody(
          options.data ?? options.form ?? (options.multipart ? '<multipart>' : undefined),
        ),
      },
      null,
      2,
    ),
  });

  let responseBody: unknown;
  const contentType = response.headers()['content-type'] ?? '';
  if (!/image|octet-stream|pdf|zip/.test(contentType)) {
    try {
      const text = await response.text();
      const redacted = redactJson(parseBody(text));
      const serialized = typeof redacted === 'string' ? redacted : JSON.stringify(redacted);
      responseBody =
        serialized.length > MAX_BODY
          ? { truncated: true, chars: serialized.length, preview: serialized.slice(0, 4000) }
          : redacted;
    } catch {
      responseBody = '<body unavailable>';
    }
  }

  await testInfo.attach('response', {
    contentType: 'application/json',
    body: JSON.stringify(
      {
        status: response.status(),
        statusText: response.statusText(),
        durationMs,
        headers: redact(response.headers()),
        body: responseBody,
      },
      null,
      2,
    ),
  });
}

export function withApiLogging(context: APIRequestContext, testInfo: TestInfo): APIRequestContext {
  return new Proxy(context, {
    get(target, prop, receiver) {
      const value = Reflect.get(target, prop, receiver);
      if (typeof value !== 'function') return value;
      if (typeof prop !== 'string' || !HTTP_METHODS.has(prop)) return value.bind(target);

      return (...args: unknown[]) => {
        const [urlOrRequest, options] = args as [
          string | Request,
          Record<string, unknown> | undefined,
        ];
        const requestOptions = options ?? {};
        const method =
          prop === 'fetch'
            ? String(requestOptions.method ?? (typeof urlOrRequest === 'string' ? 'GET' : urlOrRequest.method)).toUpperCase()
            : prop.toUpperCase();
        const url = typeof urlOrRequest === 'string' ? urlOrRequest : urlOrRequest.url;

        return test.step(`${method} ${shortUrl(redactUrl(url))}`, async () => {
          const startedAt = Date.now();
          const response: APIResponse = await value.apply(target, args);
          try {
            await attachExchange(testInfo, method, requestOptions, response, startedAt);
          } catch {
            // Reporting must never fail a test that got its response.
          }
          return response;
        });
      };
    },
  });
}
