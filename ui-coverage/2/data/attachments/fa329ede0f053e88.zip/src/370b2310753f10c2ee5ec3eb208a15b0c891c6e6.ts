import type { APIRequestContext } from '@playwright/test';
import type {
  KratosLoginFlow,
  KratosRegistrationFlow,
  KratosVerificationFlow,
  KratosWhoami,
} from '../models/kratos';
import {
  csrfTokenFromUi,
  encodeFormBody,
  flowIdFromHtml,
  flowIdFromLocation,
  loginIdentifierFieldName,
} from '../utils/kratos-flow';
import type { UserRegistrationInput } from '../factories/user-registration';
import { userRegistrationFormFields } from '../factories/user-registration';

/**
 * Identity HTTP only (Ory Kratos via `APIRequestContext`). Returns `{ status, body }`.
 * Specs assert. Throw only if the body cannot be parsed. No `page.goto` on the Kratos UI URL.
 */
export class KratosClient {
  constructor(
    private readonly request: APIRequestContext,
    private readonly siteOrigin: string,
  ) {}

  private kratosJsonHeaders(refererPath: string): Record<string, string> {
    return {
      Accept: 'application/json',
      Origin: this.siteOrigin,
      Referer: `${this.siteOrigin}${refererPath}`,
    };
  }

  /** Current session. Spec asserts status / email. */
  async whoami(): Promise<{ status: number; body: KratosWhoami }> {
    const response = await this.request.get('/.ory/kratos/sessions/whoami', {
      failOnStatusCode: false,
    });
    return { status: response.status(), body: (await response.json()) as KratosWhoami };
  }

  private async postKratosUiForm<T extends KratosLoginFlow>(
    flow: T,
    refererPath: string,
    fields: Record<string, string>,
  ): Promise<{ status: number; body: T }> {
    const action = flow.ui?.action;
    if (!action) {
      throw new Error('Kratos flow missing ui.action');
    }

    const csrf = csrfTokenFromUi(flow.ui);
    const response = await this.request.post(action, {
      headers: {
        ...this.kratosJsonHeaders(refererPath),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      data: encodeFormBody({ csrf_token: csrf, ...fields }),
      failOnStatusCode: false,
    });

    const text = await response.text();
    try {
      return { status: response.status(), body: JSON.parse(text) as T };
    } catch {
      throw new Error(`Kratos returned non-JSON (HTTP ${response.status()}): ${text.slice(0, 200)}`);
    }
  }

  private async initLoginFlow(): Promise<{ flowId: string; flow: KratosLoginFlow }> {
    const init = await this.request.get('/.ory/kratos/self-service/login/browser', {
      headers: this.kratosJsonHeaders('/en/login'),
      maxRedirects: 0,
      failOnStatusCode: false,
    });

    if (init.status() === 200) {
      const flow = (await init.json()) as KratosLoginFlow;
      if (flow.id && flow.ui) {
        return { flowId: flow.id, flow };
      }
    }

    const flowId = flowIdFromLocation(init.headers().location);
    if (!flowId) {
      throw new Error(
        `Kratos login browser flow missing flow id (HTTP ${init.status()}, location: ${init.headers().location ?? 'none'})`,
      );
    }

    const flowResponse = await this.request.get(
      `/.ory/kratos/self-service/login?flow=${flowId}`,
      { headers: this.kratosJsonHeaders('/en/login'), failOnStatusCode: false },
    );
    const flow = (await flowResponse.json()) as KratosLoginFlow;
    if (!flow.ui) {
      throw new Error(`Kratos login flow GET missing ui (HTTP ${flowResponse.status()})`);
    }
    return { flowId, flow };
  }

  /** Password login. Returns whoami; the spec asserts status / email. */
  async loginWithPassword(
    email: string,
    password: string,
  ): Promise<{ status: number; body: KratosWhoami }> {
    const existing = await this.whoami();
    if (existing.status === 200) {
      return existing;
    }

    let flow = (await this.initLoginFlow()).flow;
    const identifierField = loginIdentifierFieldName(flow.ui);

    // WLW uses a two-step login UI (email → password). Kratos returns HTTP 400 with an updated flow after step 1.
    const step = await this.postKratosUiForm(flow, '/en/login', {
      method: 'password',
      [identifierField]: email,
    });

    let session = await this.whoami();
    if (session.status !== 200 && step.body.ui) {
      flow = step.body;
      await this.postKratosUiForm(flow, '/en/login', {
        method: 'password',
        [identifierField]: email,
        password,
      });
      session = await this.whoami();
    }

    return session;
  }

  private async initRegistrationFlow(): Promise<KratosRegistrationFlow> {
    const browser = await this.request.get('/.ory/kratos/self-service/registration/browser', {
      headers: this.kratosJsonHeaders('/en/supplier-registration'),
      maxRedirects: 0,
      failOnStatusCode: false,
    });

    if (browser.status() === 200) {
      const flow = (await browser.json()) as KratosRegistrationFlow;
      if (flow.id && flow.ui) {
        return flow;
      }
    }

    const page = await this.request.get('/en/supplier-registration', {
      headers: { Accept: 'text/html' },
      failOnStatusCode: false,
    });
    const flowId = flowIdFromHtml(await page.text());
    if (!flowId) {
      throw new Error('Could not parse Kratos registration flow id from supplier-registration page');
    }

    const flowResponse = await this.request.get(
      `/.ory/kratos/self-service/registration?flow=${flowId}`,
      {
        headers: this.kratosJsonHeaders('/en/supplier-registration'),
        failOnStatusCode: false,
      },
    );
    const flowText = await flowResponse.text();
    try {
      const flow = JSON.parse(flowText) as KratosRegistrationFlow;
      if (!flow.ui) {
        throw new Error(`HTTP ${flowResponse.status()} missing ui`);
      }
      return flow;
    } catch (error) {
      throw new Error(
        `Kratos registration flow GET failed: ${error instanceof Error ? error.message : error} — ${flowText.slice(0, 200)}`,
        { cause: error },
      );
    }
  }

  /** Create-account on `/en/supplier-registration`. Yields a user, not a supplier. Spec asserts. */
  async registerUser(input: UserRegistrationInput): Promise<{
    status: number;
    body: KratosRegistrationFlow;
    identityId?: string;
    verificationFlowId?: string;
  }> {
    const flow = await this.initRegistrationFlow();

    const registerStep = await this.postKratosUiForm(flow, '/en/supplier-registration', {
      ...userRegistrationFormFields(input),
    });

    const registerBody = registerStep.body as KratosRegistrationFlow;
    const identityId = registerBody.identity?.id;
    const verificationFlowId = registerBody.continue_with?.find(
      (item) => item.action === 'show_verification_ui',
    )?.flow?.id;

    return {
      status: registerStep.status,
      body: registerBody,
      identityId,
      verificationFlowId,
    };
  }

  /** Submit the Mailtrap OTP against the verification flow id from `registerUser`. Spec asserts. */
  async submitEmailVerificationCode(
    verificationFlowId: string,
    otp: string,
  ): Promise<{ status: number; body: KratosVerificationFlow }> {
    await this.request.get(`/en/verification?flow=${verificationFlowId}`, {
      headers: { Accept: 'text/html' },
      failOnStatusCode: false,
    });

    const flowResponse = await this.request.get(
      `/.ory/kratos/self-service/verification/flows?id=${verificationFlowId}`,
      {
        headers: this.kratosJsonHeaders('/en/verification'),
        failOnStatusCode: false,
      },
    );
    const flow = (await flowResponse.json()) as KratosVerificationFlow;
    if (!flow.ui) {
      throw new Error(`Kratos verification flow GET missing ui (HTTP ${flowResponse.status()})`);
    }

    const action = flow.ui.action;
    if (!action) {
      throw new Error('Kratos verification flow missing ui.action');
    }

    const csrf = csrfTokenFromUi(flow.ui);
    const verifyPost = await this.request.post(action, {
      headers: {
        ...this.kratosJsonHeaders('/en/verification'),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      data: encodeFormBody({
        csrf_token: csrf,
        method: 'code',
        code: otp,
      }),
      failOnStatusCode: false,
    });

    const text = await verifyPost.text();
    try {
      return {
        status: verifyPost.status(),
        body: JSON.parse(text) as KratosVerificationFlow,
      };
    } catch {
      throw new Error(
        `Kratos verification returned non-JSON (HTTP ${verifyPost.status()}): ${text.slice(0, 200)}`,
      );
    }
  }
}
