/**
 * Regression: buyer My Account settings (ported from Cypress `regression/my-account/*`).
 * Requires `BUYER_*`; optional `MY_ACCOUNT_GIVEN_NAME` / `MY_ACCOUNT_SURNAME` for exact names.
 */
import { test } from '../../../fixtures';
import { hasBuyerCredentials } from '../../../config/load-platform-env';
import { myAccountExpectations, myAccountProfileExpectations } from '../../../config/my-account';
import { openMyAccountSettingsAsBuyer } from '../../flows/open-my-account-settings.flow';
import { MyAccountPage } from '../../pages/user-account/my-account.page';

test.describe('My Account settings page', () => {
  test.beforeEach(async ({ publicPage, product, apiRequest }) => {
    test.skip(
      !hasBuyerCredentials(product),
      `BUYER_EMAIL / BUYER_PASSWORD missing in .env.stage-${product}`,
    );
    await openMyAccountSettingsAsBuyer(publicPage, product, apiRequest);
  });

  test('displays page heading and user name', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
    product,
  }) => {
    const expected = myAccountExpectations(product);
    const profile = myAccountProfileExpectations(product);
    const myAccount = new MyAccountPage(publicPage);
    await myAccount.expectPageHeading(expected.pageHeading);
    if (profile) {
      await myAccount.expectGivenName(profile.givenName);
      await myAccount.expectSurname(profile.surname);
    } else {
      await myAccount.expectPersonalNameFieldsPopulated();
    }
  });

  test('has all about-me fields enabled', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
  }) => {
    const myAccount = new MyAccountPage(publicPage);
    await myAccount.expectAboutMeFieldsEnabled();
  });

  test('displays Notifications section', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
    product,
  }) => {
    const expected = myAccountExpectations(product);
    const myAccount = new MyAccountPage(publicPage);
    await myAccount.expectNotificationsSection(expected.notificationsSection);
  });

  test('displays My Companies section', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
    product,
  }) => {
    const expected = myAccountExpectations(product);
    const myAccount = new MyAccountPage(publicPage);
    await myAccount.expectMyCompaniesSection(expected.myCompaniesSection);
  });

  test('displays Language section', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
    product,
  }) => {
    const expected = myAccountExpectations(product);
    const myAccount = new MyAccountPage(publicPage);
    await myAccount.expectLanguageSection(expected.languageSection);
    if (expected.languageSelected) {
      await myAccount.expectLanguageSelected(expected.languageSelected);
    }
  });

  test('displays Account information with disabled email', {
    tag: ['@regression', '@wlw', '@ep'],
  }, async ({ publicPage, product }) => {
    const expected = myAccountExpectations(product);
    const myAccount = new MyAccountPage(publicPage);
    await myAccount.expectAccountInfoSection(expected.accountInfoSection);
  });

  test('displays Security section', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
    product,
  }) => {
    const expected = myAccountExpectations(product);
    const myAccount = new MyAccountPage(publicPage);
    await myAccount.expectSecuritySection(expected.securitySection);
  });

  test('displays footer links', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
    product,
  }) => {
    const expected = myAccountExpectations(product);
    const myAccount = new MyAccountPage(publicPage);
    await myAccount.expectFooterLinks(expected.footerLinks);
  });

  test('opens notification settings and verifies toggles', {
    tag: ['@regression', '@wlw', '@ep'],
  }, async ({ publicPage, product }) => {
    const expected = myAccountExpectations(product);
    const heading = expected.notificationSettingsHeading;
    if (!heading) {
      throw new Error(`notificationSettingsHeading missing for product ${product} in config/my-account.ts`);
    }
    const myAccount = new MyAccountPage(publicPage);
    await myAccount.openNotificationSettings();
    await myAccount.expectNotificationSettingsHeading(heading!);
    await myAccount.expectDirectMessageNotificationsOn();
    await myAccount.expectRfqNotificationsOn();
    await myAccount.expectSupplierProductNotificationsOn();
  });
});
