import { expect, type Locator, type Page } from '@playwright/test';

/** `/user-frontend/settings` and notification settings (buyer account). */
export class MyAccountPage {
  constructor(private readonly page: Page) {}

  private notificationsSectionTitle(): Locator {
    return this.page.locator('.flex.p-2 .font-display-500');
  }

  private notificationsChangeButton(): Locator {
    return this.page.locator('.flex.p-2 .btn');
  }

  private myCompaniesSectionTitle(): Locator {
    return this.page.locator(':nth-child(5) > .font-display-500');
  }

  private languageSectionTitle(): Locator {
    return this.page.locator('.font-display-500.mb-1');
  }

  private languageSectionCard(): Locator {
    return this.page
      .locator('h2')
      .filter({ hasText: /Language|Sprache/ })
      .locator('xpath=ancestor::div[contains(@class,"bg-white")][1]');
  }

  private languageSelectRoot(): Locator {
    return this.page.locator('.vis-select').filter({ has: this.page.locator('button#language') });
  }

  private languageDropdownButton(): Locator {
    return this.languageSelectRoot().locator('button#language');
  }

  private languageSaveButton(): Locator {
    return this.languageSectionCard().locator('button.btn');
  }

  private accountInfoSectionTitle(): Locator {
    return this.page.locator('.mt-3.mt-2 > .flex-wrap > .font-display-500');
  }

  private securitySectionTitle(): Locator {
    return this.page.locator(':nth-child(8) > .font-display-500');
  }

  async openSettings(
    lang: 'de' | 'en',
    waitUntil: 'domcontentloaded' | 'load' | 'networkidle' = 'domcontentloaded',
  ): Promise<void> {
    await this.page.goto(`/${lang}/user-frontend/settings`, { waitUntil });
    await expect(this.page).toHaveURL(/user-frontend\/settings/, { timeout: 15_000 });
  }

  async expectPageHeading(text: string): Promise<void> {
    await expect(this.page.locator('h1')).toHaveText(text);
  }

  async expectGivenName(value: string): Promise<void> {
    await expect(this.page.locator("#givenName[type='text']")).toHaveValue(value);
  }

  async expectSurname(value: string): Promise<void> {
    await expect(this.page.locator("#surname[type='text']")).toHaveValue(value);
  }

  async expectPersonalNameFieldsPopulated(): Promise<void> {
    const givenName = this.page.locator("#givenName[type='text']");
    const surname = this.page.locator("#surname[type='text']");
    await expect(givenName).not.toHaveValue('');
    await expect(surname).not.toHaveValue('');
  }

  async expectAboutMeFieldsEnabled(): Promise<void> {
    await expect(this.page.locator('#salutation')).toBeEnabled();
    await expect(this.page.locator('#companyName')).toBeEnabled();
    await expect(this.page.locator('#jobTitle')).toBeEnabled();
    await expect(this.page.locator('#department')).toBeEnabled();
  }

  async expectNotificationsSection(title: string): Promise<void> {
    await expect(this.notificationsSectionTitle()).toHaveText(title);
  }

  async expectMyCompaniesSection(title: string): Promise<void> {
    await expect(this.myCompaniesSectionTitle()).toHaveText(title);
    await expect(this.page.locator('a.create-company')).toBeEnabled();
  }

  async expectLanguageSection(title: string): Promise<void> {
    await expect(this.languageSectionTitle()).toHaveText(title);
    await expect(this.page.locator('button#language')).toBeEnabled();
  }

  async expectLanguageSelected(label: string): Promise<void> {
    await expect(this.page.locator('#language .option')).toHaveText(label);
  }

  async scrollToLanguageSection(): Promise<void> {
    await this.languageDropdownButton().scrollIntoViewIfNeeded();
    await expect(this.languageDropdownButton()).toBeVisible();
  }

  async preferredLanguageLabel(): Promise<string> {
    const label = await this.languageDropdownButton().locator('.option span').textContent();
    return (label ?? '').trim();
  }

  /** Vis-select dropdown is flaky to open; nudge salutation + retry (Pegasus REG-MA-02). */
  private async openLanguageDropdown(): Promise<void> {
    const select = this.languageSelectRoot();
    const button = this.languageDropdownButton();
    for (let attempt = 0; attempt < 5; attempt++) {
      await this.page.locator('button#salutation').click().catch(() => undefined);
      await this.page.keyboard.press('Escape');
      await button.scrollIntoViewIfNeeded();
      await button.click();
      const opened = await select.evaluate((root) => {
        const menu = root.querySelector('.dropdown') as HTMLElement | null;
        return Boolean(menu && getComputedStyle(menu).display === 'flex');
      });
      if (opened) return;
    }
    throw new Error('Language dropdown did not open after retries');
  }

  async selectPreferredLanguage(optionLabel: string): Promise<void> {
    await this.openLanguageDropdown();
    await this.languageSelectRoot()
      .locator('[role="menuitem"]')
      .filter({ hasText: optionLabel })
      .click();
    await expect(this.languageDropdownButton().locator('.option span')).toContainText(
      optionLabel.startsWith('Deutsch') ? 'Deutsch' : 'English',
    );
  }

  async clickLanguageSave(): Promise<void> {
    const save = this.languageSaveButton();
    await expect(save).toBeEnabled({ timeout: 30_000 });
    await save.click();
    await expect(save).toBeDisabled({ timeout: 60_000 });
  }

  async expectPreferredLanguage(optionLabel: string): Promise<void> {
    await expect(this.languageDropdownButton().locator('.option span')).toContainText(
      optionLabel.startsWith('Deutsch') ? 'Deutsch' : 'English',
    );
  }

  async expectAccountInfoSection(title: string): Promise<void> {
    await expect(this.accountInfoSectionTitle()).toHaveText(title);
    await expect(this.page.locator('#email')).toBeDisabled();
  }

  async expectSecuritySection(title: string): Promise<void> {
    await expect(this.securitySectionTitle()).toHaveText(title);
    await expect(this.page.locator('[class*="delete-button"]')).toBeEnabled();
  }

  async expectFooterLinks(expected: readonly string[]): Promise<void> {
    const links = this.page.locator('.content a.link');
    await expect(links).toHaveCount(expected.length);
    const texts = await links.allTextContents();
    expect(texts.map((t) => t.trim())).toEqual([...expected]);
  }

  async openNotificationSettings(): Promise<void> {
    await this.notificationsChangeButton().click();
  }

  async expectNotificationSettingsHeading(text: string): Promise<void> {
    await expect(this.page.locator('h1')).toHaveText(text);
  }

  async expectDirectMessageNotificationsOn(): Promise<void> {
    await expect(this.page.locator('#direct-message-enabled')).toBeChecked();
    await expect(this.page.locator('#direct-message-email-enabled')).toBeChecked();
    await expect(this.page.locator('#direct-message-email-enabled')).toBeDisabled();
  }

  async expectRfqNotificationsOn(): Promise<void> {
    await expect(this.page.locator('#request-for-quotes-enabled')).toBeChecked();
    await expect(this.page.locator('#request-for-quotes-email-enabled')).toBeChecked();
    await expect(this.page.locator('#request-for-quotes-email-enabled')).toBeDisabled();
  }

  async expectSupplierProductNotificationsOn(): Promise<void> {
    await expect(this.page.locator('#suppliers-enabled')).toBeChecked();
  }

  /** Open step only — closed steps stay in DOM without `[open]` (Cypress `dialog.vis-modal:visible`). */
  private visibleDeleteModal(): Locator {
    return this.page.locator('dialog.vis-modal').filter({ visible: true }).first();
  }

  /** Open delete-account survey (Cypress `clickDeleteAccount`). */
  async clickDeleteAccount(): Promise<void> {
    await expect(this.page).toHaveURL(/user-frontend\/settings/);
    const deleteBtn = this.page.locator('[data-testid="buyer-delete-desktop-action"]');
    await deleteBtn.scrollIntoViewIfNeeded();
    await expect(deleteBtn).toBeVisible({ timeout: 30_000 });
    await expect(deleteBtn).toBeEnabled();

    const modal = this.visibleDeleteModal();
    for (let attempt = 0; attempt < 2; attempt++) {
      await deleteBtn.click();
      try {
        await expect(modal).toBeVisible({ timeout: 15_000 });
        break;
      } catch (error) {
        if (attempt === 1) throw error;
      }
    }
    await expect(modal.locator('label:has(input[type="checkbox"])')).not.toHaveCount(0);
  }

  /** Survey + confirmation steps inside the visible delete dialog. */
  async confirmDeleteAccount(): Promise<void> {
    const modal = this.visibleDeleteModal();
    await modal.locator('label:has(input[type="checkbox"])').first().click();
    await modal.locator('button.btn--subtle:not(:disabled)').last().click();

    const confirmModal = this.visibleDeleteModal();
    await confirmModal.locator('label').filter({ hasText: /yes|löschen|delete|confirm/i }).click();
    await confirmModal.locator('button.btn--negative').click();
  }
}
