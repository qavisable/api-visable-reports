import type { APIRequestContext } from '@playwright/test';
import type { ProductFamily } from '../../../../config/platforms';
import {
  loadPlatformEnv,
  personaCredentials,
  type Persona,
} from '../../../../config/load-platform-env';
import { KratosClient } from '../clients/kratos-client';

/** Password login via Kratos API (session cookies on `apiRequest`). Spec or UI flow syncs to browser. */
export async function loginPersonaViaApi(
  apiRequest: APIRequestContext,
  product: ProductFamily,
  persona: Persona,
): Promise<void> {
  const { email, password } = personaCredentials(product, persona);
  await loginWithCredentialsViaApi(apiRequest, product, email, password);
}

export async function loginWithCredentialsViaApi(
  apiRequest: APIRequestContext,
  product: ProductFamily,
  email: string,
  password: string,
): Promise<void> {
  const kratos = new KratosClient(apiRequest, loadPlatformEnv(product).baseUrl);
  const session = await kratos.loginWithPassword(email, password);
  if (session.status !== 200) {
    throw new Error(`Kratos login failed (HTTP ${session.status})`);
  }
}
