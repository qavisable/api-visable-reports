import type { APIRequestContext, Page } from '@playwright/test';
import type { ProductFamily } from '../../config/platforms';
import { myAccountExpectations } from '../../config/my-account';
import { urlFor } from '../../config/platforms';
import { loginPersonaViaApi } from '../../api/services/identity/flows/login-persona-api.flow';
import { syncApiSessionToBrowser } from '../../fixtures/api-session';
import { ensurePageInteractive } from '../../fixtures/staging-traps';
import { MyAccountPage } from '../pages/user-account/my-account.page';

/** Sign in as `BUYER_*` via Kratos API, then open `/user-frontend/settings` (wlw de / ep en). */
export async function openMyAccountSettingsAsBuyer(
  page: Page,
  product: ProductFamily,
  apiRequest: APIRequestContext,
): Promise<MyAccountPage> {
  if (product === 'ep') {
    await page.context().addInitScript(() => {
      sessionStorage.setItem('regionMismatchDisabled', '1');
    });
  }

  await loginPersonaViaApi(apiRequest, product, 'buyer');
  await syncApiSessionToBrowser(apiRequest, page.context());
  await ensurePageInteractive(page, urlFor(product));

  const myAccount = new MyAccountPage(page);
  const locale = myAccountExpectations(product);
  await myAccount.openSettings(locale.settingsLang);

  return myAccount;
}
