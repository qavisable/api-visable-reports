const e={mobile_floating:{open:"Отваряне",title:{ep:"Отвори приложението",wlw:"Отвори приложението"}}},t={visable_vue:e};export{t as default,e as visable_vue};
