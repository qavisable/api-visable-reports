const i={mobile_floating:{open:"Abrir",title:{ep:"Abrir la aplicación",wlw:"Abrir la aplicación"}}},a={visable_vue:i};export{a as default,i as visable_vue};
