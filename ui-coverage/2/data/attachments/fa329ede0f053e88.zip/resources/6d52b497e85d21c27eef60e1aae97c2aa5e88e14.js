const e={mobile_floating:{open:"Megnyitás",title:{ep:"Alkalmazás megnyitása",wlw:"Alkalmazás megnyitása"}}},a={visable_vue:e};export{a as default,e as visable_vue};
