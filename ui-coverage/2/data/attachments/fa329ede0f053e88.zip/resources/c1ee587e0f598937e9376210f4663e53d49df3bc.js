const i={mobile_floating:{open:"Ouvrir",title:{ep:"Ouvrir l'application",wlw:"Ouvrir l'application"}}},l={visable_vue:i};export{l as default,i as visable_vue};
