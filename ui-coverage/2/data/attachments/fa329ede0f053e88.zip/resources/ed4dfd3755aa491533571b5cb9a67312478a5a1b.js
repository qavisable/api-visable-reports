const e={mobile_floating:{open:"Åpne",title:{ep:"Åpne appen",wlw:"Åpne appen"}}},n={visable_vue:e};export{n as default,e as visable_vue};
