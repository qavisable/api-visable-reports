const p={mobile_floating:{open:"Öppna",title:{ep:"Öppna appen",wlw:"Öppna appen"}}},e={visable_vue:p};export{e as default,p as visable_vue};
