const a={mobile_floating:{open:"Aç",title:{ep:"Uygulamayı aç",wlw:"Uygulamayı aç"}}},e={visable_vue:a};export{e as default,a as visable_vue};
