const e={mobile_floating:{open:"Åbn",title:{ep:"Åbn appen",wlw:"Åbn appen"}}},n={visable_vue:e};export{n as default,e as visable_vue};
