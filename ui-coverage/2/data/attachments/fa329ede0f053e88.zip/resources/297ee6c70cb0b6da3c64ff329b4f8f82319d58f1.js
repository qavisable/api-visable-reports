const e={mobile_floating:{open:"Ava",title:{ep:"Ava rakendus",wlw:"Ava rakendus"}}},a={visable_vue:e};export{a as default,e as visable_vue};
