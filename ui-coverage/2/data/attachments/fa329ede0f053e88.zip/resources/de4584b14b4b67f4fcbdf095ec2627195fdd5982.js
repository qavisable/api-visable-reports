const p={mobile_floating:{open:"Apri",title:{ep:"Apri l'app",wlw:"Apri l'app"}}},e={visable_vue:p};export{e as default,p as visable_vue};
