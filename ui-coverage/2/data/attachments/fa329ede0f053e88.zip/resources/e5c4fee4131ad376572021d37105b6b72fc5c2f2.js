const e={mobile_floating:{open:"Deschide",title:{ep:"Deschide aplicația",wlw:"Deschide aplicația"}}},i={visable_vue:e};export{i as default,e as visable_vue};
