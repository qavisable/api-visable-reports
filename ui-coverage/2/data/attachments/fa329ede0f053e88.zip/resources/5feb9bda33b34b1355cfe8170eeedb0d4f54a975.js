const e={mobile_floating:{open:"Öffnen",title:{ep:"App öffnen",wlw:"App öffnen"}}},n={visable_vue:e};export{n as default,e as visable_vue};
