const t={mobile_floating:{open:"Otevřít",title:{ep:"Otevřít aplikaci",wlw:"Otevřít aplikaci"}}},e={visable_vue:t};export{e as default,t as visable_vue};
