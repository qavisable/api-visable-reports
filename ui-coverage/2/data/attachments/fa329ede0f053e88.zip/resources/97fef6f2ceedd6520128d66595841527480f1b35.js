const a={mobile_floating:{open:"Avaa",title:{ep:"Avaa sovellus",wlw:"Avaa sovellus"}}},e={visable_vue:a};export{e as default,a as visable_vue};
