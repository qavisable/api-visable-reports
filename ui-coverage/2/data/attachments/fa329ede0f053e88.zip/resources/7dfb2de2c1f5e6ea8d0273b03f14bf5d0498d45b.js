const e={mobile_floating:{open:"Openen",title:{ep:"App openen",wlw:"App openen"}}},n={visable_vue:e};export{n as default,e as visable_vue};
