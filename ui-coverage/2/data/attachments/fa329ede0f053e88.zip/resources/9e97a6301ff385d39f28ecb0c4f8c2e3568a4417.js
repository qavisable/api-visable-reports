const t={mobile_floating:{open:"Otwórz",title:{ep:"Otwórz aplikację",wlw:"Otwórz aplikację"}}},l={visable_vue:t};export{l as default,t as visable_vue};
