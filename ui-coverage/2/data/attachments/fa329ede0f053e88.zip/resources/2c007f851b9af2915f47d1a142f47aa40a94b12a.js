const e={mobile_floating:{open:"Open",title:{ep:"Open app",wlw:"Open app"}}},p={visable_vue:e};export{p as default,e as visable_vue};
