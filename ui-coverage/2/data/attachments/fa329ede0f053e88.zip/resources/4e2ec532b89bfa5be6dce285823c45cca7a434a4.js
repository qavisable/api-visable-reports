const i={mobile_floating:{open:"Odpri",title:{ep:"Odpri aplikacijo",wlw:"Odpri aplikacijo"}}},l={visable_vue:i};export{l as default,i as visable_vue};
