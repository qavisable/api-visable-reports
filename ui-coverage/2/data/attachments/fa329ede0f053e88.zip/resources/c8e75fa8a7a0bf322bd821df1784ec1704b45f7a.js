const e={mobile_floating:{open:"Άνοιγμα",title:{ep:"Άνοιγμα εφαρμογής",wlw:"Άνοιγμα εφαρμογής"}}},l={visable_vue:e};export{l as default,e as visable_vue};
