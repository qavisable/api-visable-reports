const t={mobile_floating:{open:"Atidaryti",title:{ep:"Atidaryti programėlę",wlw:"Atidaryti programėlę"}}},i={visable_vue:t};export{i as default,t as visable_vue};
