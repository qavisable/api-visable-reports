const a={mobile_floating:{open:"Abrir",title:{ep:"Abra o aplicativo",wlw:"Abra o aplicativo"}}},o={visable_vue:a};export{o as default,a as visable_vue};
