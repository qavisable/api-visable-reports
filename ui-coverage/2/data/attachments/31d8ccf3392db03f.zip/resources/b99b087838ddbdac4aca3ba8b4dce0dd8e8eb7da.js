const O=10,o=3,_={FOLLOW:"follow",NOFOLLOW:"nofollow"};export{_ as S,O as a,o as b};
