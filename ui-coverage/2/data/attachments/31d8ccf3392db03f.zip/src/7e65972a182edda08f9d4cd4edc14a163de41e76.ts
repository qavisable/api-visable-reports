import { expect, type Locator, type Page } from '@playwright/test';
import { buyerPages } from '../../../config/buyer-pages';
import type { ProductFamily } from '../../../config/platforms';
import { dismissCookieBanner } from '../../../fixtures/staging-traps';

/**
 * Product listing screen shared by CPV (`/showroom-cate/`) and Showroom (`/showroom/`).
 * Cypress kept two byte-identical POMs; here one screen takes the path from `config/buyer-pages.ts`.
 */
export class ProductListingPage {
  constructor(
    private readonly page: Page,
    private readonly product: ProductFamily,
  ) {}

  breadcrumbs(): Locator {
    return this.page.locator('[data-test="breadcrumbs"]').first();
  }

  resultContainer(): Locator {
    return this.page.locator('[data-test="product-search-results"]').first();
  }

  productCards(): Locator {
    return this.page.locator('[data-test="product"]');
  }

  productNames(): Locator {
    return this.page.locator('[data-test="product-name"]');
  }

  companyNames(): Locator {
    return this.page.locator('[data-test="company-name"]');
  }

  filterControls(): Locator {
    return this.page.locator(
      '[data-test="multi-checkbox-filter-item"], [data-test="location-filter"], [data-test="detect-location"], [data-test="filter-sorting"]',
    );
  }

  pagination(): Locator {
    return this.page.locator('[data-test="pagination"]').first();
  }

  quotesEntry(): Locator {
    return this.page.locator('[data-test="quotes-entry"]').first();
  }

  firstProductCard(): Locator {
    return this.productCards().first();
  }

  /** Card content overlays the anchor, so the click is forced (Cypress forced it too). */
  firstProductLink(): Locator {
    return this.firstProductCard().locator('a[href]').first();
  }

  /** Accepts a relative path (product staging host) or an absolute domain-smoke URL. */
  async open(pathOrUrl: string = buyerPages(this.product).showroom): Promise<void> {
    await this.page.goto(pathOrUrl, { waitUntil: 'domcontentloaded' });
    await dismissCookieBanner(this.page);
    await expect(this.breadcrumbs()).toBeVisible({ timeout: 60_000 });
  }

  /**
   * Listing cards open the PDP in a new tab (`target="_blank"`), so the popup is returned.
   * Card content overlays the anchor, hence the forced click (Cypress forced it too).
   */
  async openFirstProduct(): Promise<Page> {
    const link = this.firstProductLink();
    await link.scrollIntoViewIfNeeded();
    const [popup] = await Promise.all([
      this.page.waitForEvent('popup'),
      link.click({ force: true }),
    ]);
    await popup.waitForLoadState('domcontentloaded');
    return popup;
  }
}
