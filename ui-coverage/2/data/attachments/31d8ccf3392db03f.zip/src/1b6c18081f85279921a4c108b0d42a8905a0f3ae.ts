import type { BrowserContext, Page } from '@playwright/test';

/**
 * Full CookieScript consent payload (account key 31639351-05f5-48c5-a489-d9cefbe6883f).
 * Prevents banner overlay on login/OTP.
 */
const COOKIE_SCRIPT_CONSENT =
  '%7B%22googleconsentmap%22%3A%7B%22ad_storage%22%3A%22targeting%22%2C%22analytics_storage%22%3A%22performance%22%2C%22ad_user_data%22%3A%22targeting%22%2C%22ad_personalization%22%3A%22targeting%22%2C%22functionality_storage%22%3A%22functionality%22%2C%22personalization_storage%22%3A%22functionality%22%2C%22security_storage%22%3A%22functionality%22%7D%2C%22bannershown%22%3A1%2C%22action%22%3A%22accept%22%2C%22consenttime%22%3A1754318310%2C%22categories%22%3A%22%5B%5C%22functionality%5C%22%2C%5C%22performance%5C%22%2C%5C%22targeting%5C%22%2C%5C%22unclassified%5C%22%5D%22%2C%22GoogleACString%22%3A%222~~dv.%22%2C%22CMP%22%3A%22CQbwIkAQbwIkAF2ACBDECHFsAP_gAEPgAAAALytR_G__bWlr-bb3aftkeYxP9_hr7sQxBgbJk24FzLvW7JwXx2E5NAzatqIKmRIAu3TBIQNlHJDURVCgKIgFryDMaEyUoTNKJ6BkiFMRI2NYCFxvm4tjWQCY5vr99lc1mB-N7dr82dzyy6hHn3a5_2S1WJCdIYetDfv8ZBKT-9IEd_x8v4v4_F7pE2-eS1n_pGvp4j9-YnM_dBmxt-bSff7Pn__rl_e7X_vd_n37v94XH77v____f_-7___2b-C8wAJhoVEEZZECAQKBhBAgAUFYQAUCAIAAEgaICAEwYFOQMAF1hMgBACgAGCAEAAIMAAQAACQAIRABQAQCAECAQKAAMACAICABgYAAwAWIgEAAIDoGKYEEAgWACRmVQaYEoACQQEtlQgkAwIK4QhFngEECImCgAABAAKAAAAeCwEJJASsSCALiCaAAAgAACiBEgRSFmAIKgzRaCsCTiMjTAMHzBMkp0GQBMEZGSbEJvwmHikKIUEOQGxSzAHTxQAAA.YAAAAAAAAAAA%22%2C%22key%22%3A%2231639351-05f5-48c5-a489-d9cefbe6883f%22%7D';

/** Registrable domain with a leading dot, so a cookie covers `www` and all subdomains. */
export function cookieDomainFromBaseUrl(baseUrl: string): string {
  const hostname = new URL(baseUrl).hostname;
  const bare = hostname.startsWith('www.') ? hostname.slice(4) : hostname;
  return `.${bare}`;
}

/** Set consent cookie on the registrable domain (covers www + subpaths). */
export async function suppressCookieBanner(context: BrowserContext, baseUrl: string): Promise<void> {
  const domain = cookieDomainFromBaseUrl(baseUrl);
  await context.addCookies([
    {
      name: 'CookieScriptConsent',
      value: COOKIE_SCRIPT_CONSENT,
      domain,
      path: '/',
      sameSite: 'Lax',
    },
  ]);
}

/** Stop CookieScript SDK from injecting the overlay mid-flow (e.g. on /verification). */
export async function installCookieBannerGuards(context: BrowserContext): Promise<void> {
  await context.route('**/cookie-script.com/**', (route) => route.abort());
  await context.route('**/cookiescript.com/**', (route) => route.abort());
  await context.route('**/cdn.cookie-script.com/**', (route) => route.abort());

  await context.addInitScript(() => {
    const style = document.createElement('style');
    style.textContent = `
      #cookiescript_injected_wrapper,
      #cookiescript_injected,
      #cookiescript_container,
      #cookiescript_overlay,
      .cookiescript_overlay {
        display: none !important;
        pointer-events: none !important;
        visibility: hidden !important;
      }
    `;
    const attach = () => {
      if (document.documentElement) {
        document.documentElement.appendChild(style);
      }
    };
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', attach, { once: true });
    } else {
      attach();
    }
  });
}

/** Recaptcha and similar public-form blockers. Shared by UI specs, not inlined in tests. */
export async function installStagingRouteStubs(context: BrowserContext): Promise<void> {
  await installCookieBannerGuards(context);
  await context.route('**/recaptcha/**', async (route) => {
    await route.fulfill({ status: 200, body: '' });
  });
  await context.route('**/google.com/recaptcha/**', async (route) => {
    await route.fulfill({ status: 200, body: '' });
  });
}

const COOKIE_ACCEPT_PATTERN =
  /accept all|alle akzeptieren|akzeptieren|accept|zustimmen|agree/i;

/** Dismiss or remove CookieScript UI if it still rendered. */
export async function dismissCookieBanner(page: Page): Promise<void> {
  const accept = page.getByRole('button', { name: COOKIE_ACCEPT_PATTERN });
  const overlay = page.locator('#cookiescript_injected_wrapper, .cookiescript_overlay');

  for (let attempt = 0; attempt < 3; attempt += 1) {
    if (await accept.first().isVisible().catch(() => false)) {
      await accept.first().click({ force: true, timeout: 3_000 }).catch(() => undefined);
    }
    await removeCookieScriptDom(page);

    if (!(await overlay.first().isVisible().catch(() => false))) {
      return;
    }

    await overlay.first().waitFor({ state: 'hidden', timeout: 5_000 }).catch(() => undefined);
    if (!(await overlay.first().isVisible().catch(() => false))) {
      return;
    }
  }
}

async function removeCookieScriptDom(page: Page): Promise<void> {
  await page
    .evaluate(() => {
      const ids = [
        'cookiescript_injected',
        'cookiescript_injected_wrapper',
        'cookiescript_container',
        'cookiescript_overlay',
      ];
      for (const id of ids) {
        document.getElementById(id)?.remove();
      }
      document.querySelectorAll('.cookiescript_overlay').forEach((el) => el.remove());
      document.body.classList.remove('cookiescript_overlay');
    })
    .catch(() => undefined);
}

/** Call before interacting with OTP or other fields under a late cookie banner. */
export async function ensurePageInteractive(page: Page, baseUrl: string): Promise<void> {
  const domain = cookieDomainFromBaseUrl(baseUrl);
  await page.context().addCookies([
    {
      name: 'CookieScriptConsent',
      value: COOKIE_SCRIPT_CONSENT,
      domain,
      path: '/',
      sameSite: 'Lax',
    },
  ]);
  await dismissCookieBanner(page);
}
