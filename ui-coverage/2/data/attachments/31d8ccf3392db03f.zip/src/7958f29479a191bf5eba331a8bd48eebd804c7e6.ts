/** CR-11: category product listing SEO dynamic elements + functional checks (WLW + EP). */
import { expect, test } from '../../../fixtures';
import { buyerPages } from '../../../config/buyer-pages';
import { ProductListingPage } from '../../pages/product/product-listing.page';
import {
  expectBasicSeoTags,
  expectSeoDynamicContent,
  expectStructuredDataIfPresent,
} from '../../pages/shared/seo-checks';

test('passes CR-11 category listing SEO and functional checks', {
  tag: ['@critical', '@regression', '@wlw', '@ep'],
}, async ({ publicPage, product }) => {
  const listing = new ProductListingPage(publicPage, product);
  await listing.open(buyerPages(product).categoryListing);

  await expectBasicSeoTags(publicPage);
  await expectSeoDynamicContent(publicPage);
  await expectStructuredDataIfPresent(publicPage);

  await expect(listing.breadcrumbs()).toBeVisible();
  await expect(listing.filterControls().first()).toBeAttached();
  await expect.poll(() => listing.productCards().count(), { timeout: 30_000 }).toBeGreaterThanOrEqual(1);

  const card = listing.firstProductCard();
  await expect(card.locator('[data-test="product-name"]').first()).toBeVisible();
  await expect(card.locator('[data-test="company-name"]').first()).toBeAttached();
  await expect(listing.pagination()).toBeAttached();
});
