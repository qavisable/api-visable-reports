/**
 * Playwright `test.extend`. Specs `import { test, expect } from '.../fixtures'`
 * then `async ({ product, publicPage, apiRequest }) => { ... }`.
 * Those names are injected here — not arguments you pass in.
 * `product` is the Playwright project (`wlw` | `ep`) and selects `.env.stage-*`.
 */
import { test as base, type APIRequestContext, type Page } from '@playwright/test';
import { bypassHeaders, hasSupplierFactsApiEnv, loadPlatformEnv } from '../config/load-platform-env';
import { productFromProjectName, urlFor, type ProductFamily } from '../config/platforms';
import { stagingBypassToken } from './secrets';
import { installStagingRouteStubs, suppressCookieBanner } from './staging-traps';
import { newSupplierFactsApiRequest } from './supplier-facts-api-request';
import { withApiLogging } from './api-logging';
import { expect } from './expect';

export { expect };

/** Fixture bag for `async ({ product, publicPage, apiRequest }) =>` in specs. */
export type PlatformFixtures = {
  /** Playwright project: `wlw` or `ep`. Tags `@wlw` / `@ep` pick which env file loads. */
  product: ProductFamily;
  /** Browser page: staging bypass header, cookie banner suppressed, recaptcha stubbed. */
  publicPage: Page;
  /** HTTP client for that product: `baseURL` + `X-Visable-Bypass-Token`. Not a browser. */
  apiRequest: APIRequestContext;
  /** Supplier Facts API host + OAuth. */
  supplierFactsApiRequest: APIRequestContext;
};

export const test = base.extend<PlatformFixtures>({
  product: async ({}, use, testInfo) => {
    await use(productFromProjectName(testInfo.project.name));
  },

  publicPage: async ({ page, context, product }, use) => {
    test.skip(!stagingBypassToken(product), `STAGING_BYPASS_TOKEN missing in .env.stage-${product}`);
    await suppressCookieBanner(context, urlFor(product));
    await installStagingRouteStubs(context);
    await use(page);
  },

  apiRequest: async ({ playwright, product }, use, testInfo) => {
    test.skip(!stagingBypassToken(product), `STAGING_BYPASS_TOKEN missing in .env.stage-${product}`);
    const { baseUrl } = loadPlatformEnv(product);
    const context = await playwright.request.newContext({
      baseURL: baseUrl,
      extraHTTPHeaders: bypassHeaders(product),
    });
    await use(withApiLogging(context, testInfo));
    await context.dispose();
  },

  supplierFactsApiRequest: async ({ playwright, product }, use, testInfo) => {
    test.skip(
      !hasSupplierFactsApiEnv(product),
      `SUPPLIER_FACTS_API_BASE_URL and OAuth keys required in .env.stage-${product}`,
    );
    const context = await newSupplierFactsApiRequest(playwright, product);
    await use(withApiLogging(context, testInfo));
    await context.dispose();
  },
});
