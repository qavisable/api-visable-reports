/**
 * Regression: category product listing (CPV) — port of Cypress `wlw-cpv-regression` and
 * `ep-cpv-regression`. CPV and Showroom share `ProductListingPage`.
 */
import { expect, test } from '../../../fixtures';
import { buyerPages } from '../../../config/buyer-pages';
import { ProductListingPage } from '../../pages/product/product-listing.page';

let listing: ProductListingPage;

test.beforeEach(async ({ publicPage, product }) => {
  listing = new ProductListingPage(publicPage, product);
  await listing.open(buyerPages(product).categoryListing);
});

test('loads the CPV URL with the showroom-cate path', {
  tag: ['@smoke', '@regression', '@wlw', '@ep'],
}, async ({ publicPage }) => {
  await expect(publicPage).toHaveURL(/\/showroom-cate\//);
});

test('shows breadcrumbs', { tag: ['@smoke', '@regression', '@wlw', '@ep'] }, async () => {
  await expect(listing.breadcrumbs()).toBeVisible();
});

test('shows filter controls', { tag: ['@regression', '@wlw', '@ep'] }, async () => {
  await expect(listing.filterControls().first()).toBeAttached();
});

test('shows product cards', { tag: ['@smoke', '@regression', '@wlw', '@ep'] }, async () => {
  await expect
    .poll(() => listing.productCards().count(), { timeout: 30_000 })
    .toBeGreaterThanOrEqual(1);
});

test('shows the first product card structure', { tag: ['@regression', '@wlw', '@ep'] }, async () => {
  const card = listing.firstProductCard();
  await expect(card.locator('[data-test="product-name"]').first()).toBeVisible();
  await expect(card.locator('[data-test="company-name"]').first()).toBeAttached();
});

test('shows pagination', { tag: ['@regression', '@wlw', '@ep'] }, async () => {
  await expect(listing.pagination()).toBeAttached();
});

test('navigates away from the CPV when clicking the first product', {
  tag: ['@regression', '@wlw', '@ep'],
}, async () => {
  const detail = await listing.openFirstProduct();
  await expect
    .poll(() => new URL(detail.url()).pathname, { timeout: 30_000 })
    .not.toContain('/showroom-cate/');
});
