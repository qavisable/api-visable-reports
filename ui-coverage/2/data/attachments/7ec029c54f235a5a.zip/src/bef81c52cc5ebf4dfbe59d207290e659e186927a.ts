import { type Page } from '@playwright/test';
import type { ProductFamily } from '../../config/platforms';
import { waitForMailtrapOtp } from '../../fixtures/mailtrap';
import {
  createDisposableRegistrationEmail,
  createDisposableRegistrationPassword,
} from '../../fixtures/test-data';
import { EmailVerificationPage } from '../pages/registration/email-verification.page';
import { RegistrationPage } from '../pages/registration/registration.page';

export type VerifiedUserAccount = {
  email: string;
  password: string;
};

export type RegisterVerifiedUserProfile = {
  firstName: string;
  surname: string;
  phoneCountry?: string;
  phone?: string;
};

const defaultProfile: RegisterVerifiedUserProfile = {
  firstName: 'QA',
  surname: 'Mailtrap',
  phoneCountry: 'Albania',
  phone: '12345678',
};

/** E2E arrange: create-account form + Mailtrap OTP. A user, not yet a supplier. Feature gold is `create-account.spec.ts`. */
export async function registerVerifiedUser(
  page: Page,
  product: ProductFamily,
  mailtrap: { apiToken: string; sandboxId: string },
  profile: RegisterVerifiedUserProfile = defaultProfile,
): Promise<VerifiedUserAccount> {
  const email = createDisposableRegistrationEmail();
  const password = createDisposableRegistrationPassword();
  const registrationStartedAt = new Date().toISOString();
  const registration = new RegistrationPage(page, product);
  const verification = new EmailVerificationPage(page, product);

  await registration.open();
  await registration.fillRegistrationForm({ ...profile, email, password });
  await registration.submit();
  await verification.expectOtpStep();

  const { otp } = await waitForMailtrapOtp({
    apiToken: mailtrap.apiToken,
    sandboxId: mailtrap.sandboxId,
    toEmail: email,
    subjectHint: 'confirm',
    receivedAfterIso: registrationStartedAt,
    timeoutMs: 90_000,
  });

  await verification.completeOtpVerification(otp);

  return { email, password };
}
