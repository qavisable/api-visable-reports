/**
 * Regression: register disposable user, re-login, delete account from settings.
 * Cypress: `wlw-disposable-account-registration.cy.ts` (second `it` only).
 */
import { expect, test } from '../../../fixtures';
import { myAccountExpectations } from '../../../config/my-account';
import { clearBrowserSession } from '../../../fixtures/clear-browser-session';
import { hasMailtrapEnv, mailtrapSettings } from '../../../config/load-platform-env';
import { loginDisposableUserViaUi } from '../../flows/login-disposable-user.flow';
import { registerVerifiedUser } from '../../flows/register-verified-user.flow';
import { MyAccountPage } from '../../pages/user-account/my-account.page';

test('disposable user can register and delete account from settings', {
  tag: ['@regression', '@wlw', '@ep'],
}, async ({ publicPage, product }) => {
  test.skip(!hasMailtrapEnv(product), `MAILTRAP_API_TOKEN missing in .env.stage-${product}`);
  test.setTimeout(300_000);

  const mailtrap = mailtrapSettings(product);
  const account = await registerVerifiedUser(publicPage, product, mailtrap, {
    firstName: 'QA',
    surname: 'Mailtrap',
    phoneCountry: 'Albania',
    phone: '12345678',
  });

  await clearBrowserSession(publicPage.context());
  await loginDisposableUserViaUi(publicPage, product, account.email, account.password);

  await publicPage.setViewportSize({ width: 1920, height: 1080 });
  const locale = myAccountExpectations(product);
  const myAccount = new MyAccountPage(publicPage);
  await myAccount.openSettings(locale.settingsLang, 'load');
  await myAccount.clickDeleteAccount();
  await myAccount.confirmDeleteAccount();
  await expect(publicPage).not.toHaveURL(/user-frontend\/settings/, { timeout: 20_000 });
});
