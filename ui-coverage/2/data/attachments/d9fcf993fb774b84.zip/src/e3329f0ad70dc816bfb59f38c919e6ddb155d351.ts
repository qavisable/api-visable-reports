import { expect, type Page } from '@playwright/test';

/** Supplier my-account areas (insights, visitors, …) — not a page class. */
export async function assertNoSupplierAccessDenied(page: Page): Promise<void> {
  const denied = page.getByRole('heading', { name: /do not have access/i });
  await expect(denied).not.toBeVisible({ timeout: 8_000 });
}

/** Fails when the Nuxt shell loaded but the dashboard API returned forbidden / error. */
export async function assertBusinessInsightsDashboardLoaded(page: Page): Promise<void> {
  await assertNoSupplierAccessDenied(page);

  const errorHeading = page.getByRole('heading', { name: /sorry, something went wrong/i });
  await expect(errorHeading).not.toBeVisible({ timeout: 8_000 });

  await expect(page.locator('[role="group"]')).toBeVisible({ timeout: 30_000 });
}
