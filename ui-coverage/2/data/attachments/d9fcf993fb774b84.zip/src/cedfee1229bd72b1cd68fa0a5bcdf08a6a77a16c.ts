import { expect, type Page } from '@playwright/test';
import { assertBusinessInsightsDashboardLoaded } from '../../flows/assert-supplier-access.flow';

/** `/en/my-account/business-insights/{supplierId}` (Cypress BusinessInsightsPage). */
export class BusinessInsightsPage {
  constructor(private readonly page: Page) {}

  async open(supplierId: string): Promise<void> {
    await this.page.goto(`/en/my-account/business-insights/${supplierId}`, {
      waitUntil: 'domcontentloaded',
    });
    await expect(this.page).toHaveURL(/business-insights/, { timeout: 15_000 });
    await assertBusinessInsightsDashboardLoaded(this.page);
  }

  async expectPageHeading(): Promise<void> {
    await expect(this.page.locator('h1')).toContainText('Business Insights');
  }

  async expectSidebarNavigation(): Promise<void> {
    await expect(this.page.locator('.link--active')).toContainText('Insights');
  }

  async expectTabsDisplayed(tabLabels: readonly string[]): Promise<void> {
    const tabNav = this.page.locator('[role="group"]');
    await expect(tabNav).toBeVisible();
    for (const label of tabLabels) {
      const tab = tabNav.getByText(label, { exact: true });
      await tab.scrollIntoViewIfNeeded();
      await expect(tab).toBeVisible();
    }
  }

  async expectDateFilterDisplayed(): Promise<void> {
    await expect(this.page.getByRole('button', { name: 'Last 12 months' })).toBeVisible();
  }

  async expectDownloadButtonDisplayed(): Promise<void> {
    await expect(this.page.getByRole('button', { name: 'Download' })).toBeVisible();
  }

  async expectVisibilitySection(): Promise<void> {
    const heading = this.page.getByRole('heading', { name: 'Your visibility' });
    await heading.scrollIntoViewIfNeeded();
    await expect(heading).toBeVisible();
    await expect(this.page.getByText('Impressions', { exact: true }).first()).toBeVisible();
    await expect(this.page.getByText('Page views', { exact: true }).first()).toBeVisible();
  }

  async expectConnectionsSection(): Promise<void> {
    const heading = this.page.getByRole('heading', { name: 'Your connections to buyers' });
    await heading.scrollIntoViewIfNeeded();
    await expect(heading).toBeVisible();
    await expect(this.page.getByText('Buyer requests', { exact: true }).first()).toBeVisible();
    await expect(this.page.getByText('Clicks to your website', { exact: true }).first()).toBeVisible();
    await expect(this.page.getByText('Clicks to your phone number', { exact: true }).first()).toBeVisible();
  }

  async expectProductsTable(): Promise<void> {
    const heading = this.page.getByRole('heading', { name: 'Your products and services' });
    await heading.scrollIntoViewIfNeeded();
    await expect(heading).toBeVisible();
    const table = this.page.locator('table').nth(0);
    await expect(table).toBeVisible();
    await expect(table.getByRole('columnheader', { name: 'Impressions', exact: true })).toBeVisible();
    await expect(table.locator('tbody tr').first()).toBeVisible();
  }

  async expectProductFilterMenu(): Promise<void> {
    const menuitems = this.page.locator('[role="menuitem"]');
    await expect(this.page.locator('[role="menu"]')).toBeAttached();
    await expect(menuitems.nth(2)).toBeVisible({ timeout: 15_000 });
  }

  async expectSearchInput(): Promise<void> {
    await expect(this.page.getByTestId('search-input')).toBeVisible();
  }

  async expectVisitorsTable(): Promise<void> {
    const heading = this.page.getByRole('heading', { name: 'Your latest identified visitors' });
    await heading.scrollIntoViewIfNeeded();
    await expect(heading).toBeVisible();
    const table = this.page.locator('table').nth(1);
    await expect(table).toBeVisible();
    await expect(table.getByRole('columnheader', { name: 'Country', exact: true })).toBeVisible();
    await expect(table.getByRole('columnheader', { name: 'Date', exact: true })).toBeVisible();
  }

  async expectCountryTable(): Promise<void> {
    const heading = this.page.getByRole('heading', { name: 'Your visibility by country' });
    await heading.scrollIntoViewIfNeeded();
    await expect(heading).toBeVisible();
    const table = this.page.locator('table').nth(2);
    await expect(table).toBeVisible();
    await expect(table.getByRole('columnheader', { name: 'Impressions', exact: true })).toBeVisible();
    await expect(table.locator('tbody tr').first()).toBeVisible();
  }

  async expectRequestHubBanner(): Promise<void> {
    const banner = this.page.getByText('Request Hub - More requests');
    await banner.scrollIntoViewIfNeeded();
    await expect(banner).toBeVisible();
  }
}
