/**
 * Regression: supplier Business Insights dashboard (`@wlw` `@ep`).
 * Cypress: `ep-business-insights-regression.cy.ts`. Per platform: `BUSINESS_INSIGHTS_SUPPLIER_*` in `.env.stage-{product}` (skips when incomplete).
 */
import { test } from '../../../fixtures';
import { businessInsightsTabLabels } from '../../../config/business-insights';
import {
  businessInsightsSupplierId,
  hasBusinessInsightsSupplierCredentials,
} from '../../../config/load-platform-env';
import { prepareBusinessInsightsSupplierBrowserSession } from '../../flows/prepare-supplier-browser-session.flow';
import { BusinessInsightsPage } from '../../pages/user-account/business-insights.page';

test.describe('Business Insights', () => {
  test.beforeEach(async ({ publicPage, product, apiRequest }) => {
    test.skip(
      !hasBusinessInsightsSupplierCredentials(product),
      `BUSINESS_INSIGHTS_SUPPLIER_EMAIL, BUSINESS_INSIGHTS_SUPPLIER_PASSWORD, or BUSINESS_INSIGHTS_SUPPLIER_ID missing in .env.stage-${product}`,
    );
    test.setTimeout(300_000);
    await prepareBusinessInsightsSupplierBrowserSession(publicPage, product, apiRequest);
    const insights = new BusinessInsightsPage(publicPage);
    await insights.open(businessInsightsSupplierId(product));
  });

  test('displays the page heading and sidebar navigation', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
  }) => {
    const insights = new BusinessInsightsPage(publicPage);
    await insights.expectPageHeading();
    await insights.expectSidebarNavigation();
  });

  test('displays Products and profile / Google Ads tabs', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
    product,
  }) => {
    const insights = new BusinessInsightsPage(publicPage);
    await insights.expectTabsDisplayed(businessInsightsTabLabels(product));
  });

  test('displays date filter and download button', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
  }) => {
    const insights = new BusinessInsightsPage(publicPage);
    await insights.expectDateFilterDisplayed();
    await insights.expectDownloadButtonDisplayed();
  });

  test('displays Your visibility section', { tag: ['@regression', '@wlw', '@ep'] }, async ({ publicPage }) => {
    const insights = new BusinessInsightsPage(publicPage);
    await insights.expectVisibilitySection();
  });

  test('displays Your connections to buyers section', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
  }) => {
    const insights = new BusinessInsightsPage(publicPage);
    await insights.expectConnectionsSection();
  });

  test('displays products and services table', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
  }) => {
    const insights = new BusinessInsightsPage(publicPage);
    await insights.expectProductsTable();
    await insights.expectProductFilterMenu();
    await insights.expectSearchInput();
  });

  test('displays latest identified visitors table', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
  }) => {
    const insights = new BusinessInsightsPage(publicPage);
    await insights.expectVisitorsTable();
  });

  test('displays visibility by country table', { tag: ['@regression', '@wlw', '@ep'] }, async ({
    publicPage,
  }) => {
    const insights = new BusinessInsightsPage(publicPage);
    await insights.expectCountryTable();
  });

  test('displays the Request Hub banner', { tag: ['@regression', '@wlw', '@ep'] }, async ({ publicPage }) => {
    const insights = new BusinessInsightsPage(publicPage);
    await insights.expectRequestHubBanner();
  });
});
