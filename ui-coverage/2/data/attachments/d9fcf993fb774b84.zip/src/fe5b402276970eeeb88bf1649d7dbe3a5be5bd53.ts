import type { APIRequestContext, Page } from '@playwright/test';
import type { ProductFamily } from '../../config/platforms';
import { urlFor } from '../../config/platforms';
import { loginPersonaViaApi, loginWithCredentialsViaApi } from '../../api/services/identity/flows/login-persona-api.flow';
import { businessInsightsSupplierCredentials } from '../../config/load-platform-env';
import { syncApiSessionToBrowser } from '../../fixtures/api-session';
import { ensurePageInteractive } from '../../fixtures/staging-traps';

/** `SUPPLIER_*` Kratos session in the browser (EP region bypass when needed). */
export async function prepareSupplierBrowserSession(
  page: Page,
  product: ProductFamily,
  apiRequest: APIRequestContext,
): Promise<void> {
  if (product === 'ep') {
    await page.context().addInitScript(() => {
      sessionStorage.setItem('regionMismatchDisabled', '1');
    });
  }

  await loginPersonaViaApi(apiRequest, product, 'supplier');
  await syncApiSessionToBrowser(apiRequest, page.context());
  await ensurePageInteractive(page, urlFor(product));
}

/** Visitors / business insights (Cypress `business-insights-supplier`; cross-market supplier on wlw + ep). */
export async function prepareBusinessInsightsSupplierBrowserSession(
  page: Page,
  product: ProductFamily,
  apiRequest: APIRequestContext,
): Promise<void> {
  await page.context().addInitScript(() => {
    sessionStorage.setItem('regionMismatchDisabled', '1');
  });

  const { email, password } = businessInsightsSupplierCredentials(product);
  await loginWithCredentialsViaApi(apiRequest, product, email, password);
  await syncApiSessionToBrowser(apiRequest, page.context());
  await ensurePageInteractive(page, urlFor(product));
}
