import{a2 as o}from"#entry";const f=()=>o;export{f as default};
