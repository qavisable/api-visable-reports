import { expect, type Locator, type Page } from '@playwright/test';
import { dismissCookieBanner, ensurePageInteractive } from '../../../fixtures/staging-traps';
import { urlFor, type ProductFamily } from '../../../config/platforms';
import { loadPlatformEnv } from '../../../config/load-platform-env';

/**
 * Europages homepage (`/`). Locator port of the Cypress `EpHomePage`.
 * Locators and `search()` live here; assertions live in the spec.
 */
export class EpHomePage {
  constructor(
    private readonly page: Page,
    private readonly product: ProductFamily = 'ep',
  ) {}

  // ── Search ────────────────────────────────────────────────────────
  /** Search box is client-side hydrated; it has aria-label "Search form", no `input[name="q"]`. */
  searchInput(): Locator {
    return this.page.getByRole('textbox', { name: /search/i }).first();
  }

  searchSubmit(): Locator {
    return this.page.getByRole('button', { name: 'Search', exact: true }).first();
  }

  // ── Header ────────────────────────────────────────────────────────
  epLogo(): Locator {
    return this.page.locator('.ep-logo');
  }

  headerGetQuotesButton(): Locator {
    return this.page.locator('.get-quotes-button');
  }

  headerRequestHubButton(): Locator {
    return this.page.locator('.request-hub-button');
  }

  /** `.registration-button` still hosts this CTA; the label changed from "List my company". */
  headerBecomeSupplierButton(): Locator {
    return this.page.locator('.registration-button');
  }

  /** Accessible name is "account Sign in" (icon alt + label). */
  headerSignIn(): Locator {
    return this.page.getByRole('button', { name: /sign in$/i }).first();
  }

  headerNavLinks(): Locator {
    return this.page.locator('header a[href], [role="banner"] a[href], nav a[href]');
  }

  // ── Hero ──────────────────────────────────────────────────────────
  heroHeading(): Locator {
    return this.page.locator('[data-test="hero-heading"]');
  }

  heroRfqButton(): Locator {
    return this.page.locator('[data-test="rfq-button"]');
  }

  // ── Product carousels (shared) ────────────────────────────────────
  productNameLinks(): Locator {
    return this.page.locator('[data-test="productNameLink"]');
  }

  companyNameLinks(): Locator {
    return this.page.locator('[data-test="productNameLink"][href*="/en/company"]');
  }

  // ── Product recommendation carousel ───────────────────────────────
  productRecNextArrow(): Locator {
    return this.page.locator('.arrows-inset-12 [class*="-right-3"]').first();
  }

  productRecPrevArrow(): Locator {
    return this.page.locator('.arrows-inset-12 [class*="-left-3"]').first();
  }

  contentItems(): Locator {
    return this.page.locator('.content-item');
  }

  // ── Trending products carousel ────────────────────────────────────
  trendingNextArrow(): Locator {
    return this.page.locator('.bg-blue-10 [class*="-right-3"]').first();
  }

  // ── CPV category section ──────────────────────────────────────────
  cpvSecondLevelLinks(): Locator {
    return this.page.locator('[data-test="secondLevelChild"]');
  }

  // ── Become part of the marketplace ────────────────────────────────
  premiumProfileButton(): Locator {
    return this.page.locator('[data-test="rfc-button"]');
  }

  createProfileLink(): Locator {
    return this.page.locator('[data-test="register-button"]');
  }

  /** The wrapper div shares the data-test; only the `<a>` carries the href. */
  requestHubLink(): Locator {
    return this.page.locator('a[data-test="request-hub-button"]');
  }

  // ── Inside Business ───────────────────────────────────────────────
  insideBusinessBlogLink(): Locator {
    return this.page.locator('a[href*="/inside-business/start"]');
  }

  insideBusinessArticles(): Locator {
    return this.page.locator('a.card-hover[href*="/inside-business/"]');
  }

  // ── Person intro ──────────────────────────────────────────────────
  personIntroImage(): Locator {
    return this.page.locator('img[src*="bg2"]').first();
  }

  // ── Brand intro ───────────────────────────────────────────────────
  brandTitle(): Locator {
    return this.page.locator('.brand-title');
  }

  brandText(): Locator {
    return this.page.locator('.brand-text');
  }

  /** Footer SEO keyword lists (Explore suppliers / Top Searches). */
  keywordListLinks(hrefPart: string): Locator {
    return this.page.locator(`a.vis-keywords-list-word[href*="${hrefPart}"]`);
  }

  async open(): Promise<void> {
    await ensurePageInteractive(this.page, urlFor(this.product));
    await this.page.goto(loadPlatformEnv(this.product).homepagePath, {
      waitUntil: 'domcontentloaded',
    });
    await dismissCookieBanner(this.page);
  }

  /** Domain smoke: open an absolute staging homepage. */
  async openAt(baseUrl: string): Promise<void> {
    await ensurePageInteractive(this.page, baseUrl);
    await this.page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
    await dismissCookieBanner(this.page);
    await expect(this.searchInput()).toBeVisible({ timeout: 60_000 });
  }

  /** Fill the hero search and submit; resolves once the browser left the homepage. */
  async search(query: string): Promise<void> {
    await this.searchInput().fill(query);
    await this.searchSubmit().click();
    const homePath = loadPlatformEnv(this.product).homepagePath.replace(/\/$/, '');
    await expect
      .poll(() => new URL(this.page.url()).pathname.replace(/\/$/, ''), { timeout: 30_000 })
      .not.toBe(homePath);
  }
}
