/**
 * `expect` whose every matcher call becomes an Allure step carrying its expected
 * value, so the report lists assertions instead of bare `Expect "toBe"` lines.
 * API assertions are synchronous; web-first assertions (`expect(locator)`,
 * `expect(page)`, `expect(response).toBeOK()`) return promises and need the
 * async step API. `expect.poll` stays untouched for the same reason.
 */
import { expect as baseExpect } from '@playwright/test';
import { step as asyncStep } from 'allure-js-commons';
import { step } from 'allure-js-commons/sync';

const MAX_PREVIEW = 80;

function preview(value: unknown): string {
  if (typeof value === 'string') {
    const text = value.length > MAX_PREVIEW ? `${value.slice(0, MAX_PREVIEW)}…` : value;
    return JSON.stringify(text);
  }
  if (
    value === null ||
    typeof value === 'number' ||
    typeof value === 'boolean' ||
    typeof value === 'undefined'
  ) {
    return String(value);
  }
  if (value instanceof RegExp) return String(value);
  try {
    const json = JSON.stringify(value);
    if (json !== undefined) return json.length > MAX_PREVIEW ? `${json.slice(0, MAX_PREVIEW)}…` : json;
  } catch {
    // circular structures fall through to the type preview
  }
  if (Array.isArray(value)) return `Array(${value.length})`;
  if (value instanceof Map) return `Map(${value.size})`;
  if (value instanceof Set) return `Set(${value.size})`;
  if (typeof value === 'object') {
    return (value as object).constructor?.name ?? 'object';
  }
  return String(value);
}

type MatcherFunction = (...args: unknown[]) => unknown;
type Matchers = Record<PropertyKey, unknown>;

/** Web-first assertions poll and return a promise; locators, pages and API responses use them. */
function isAsyncTarget(actual: unknown): boolean {
  if (!actual || typeof actual !== 'object') return false;
  const target = actual as Record<string, unknown>;
  if (typeof target._frame === 'object' && target._frame !== null) return true;
  if (typeof target.goto === 'function' && typeof target.context === 'function') return true;
  return typeof target.status === 'function' && typeof target.headersArray === 'function';
}

function withSteps(matchers: Matchers, negated: boolean, actual: unknown): Matchers {
  return new Proxy(matchers, {
    get(target, prop, receiver) {
      const value = Reflect.get(target, prop, receiver);
      if (typeof prop !== 'string') return value;
      if (prop === 'not') return withSteps(value as Matchers, !negated, actual);
      if (typeof value !== 'function') return value;
      return (...args: unknown[]) => {
        const title = `assert ${negated ? 'not ' : ''}${prop}(${args.map(preview).join(', ')})`;
        const matcher = () => (value as MatcherFunction).apply(target, args);
        if (isAsyncTarget(actual)) return asyncStep(title, matcher);
        return step(title, matcher);
      };
    },
  });
}

export const expect = new Proxy(baseExpect, {
  apply(target, _thisArg, args: [unknown, ...unknown[]]) {
    return withSteps(
      (target as unknown as (...a: unknown[]) => Matchers)(...args),
      false,
      args[0],
    );
  },
  get(target, prop, receiver) {
    const value = Reflect.get(target, prop, receiver);
    if (prop === 'soft') {
      return (actual: unknown, message?: string) =>
        withSteps(
          (value as (a: unknown, m?: string) => Matchers)(actual, message),
          false,
          actual,
        );
    }
    if (prop === 'poll') {
      return (...args: unknown[]) => (value as (...a: unknown[]) => unknown)(...args);
    }
    return typeof value === 'function' ? value.bind(target) : value;
  },
}) as unknown as typeof baseExpect;
