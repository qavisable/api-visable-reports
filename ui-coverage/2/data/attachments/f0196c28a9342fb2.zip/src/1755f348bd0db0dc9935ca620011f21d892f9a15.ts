import { expect, type Locator, type Page } from '@playwright/test';
import { dismissCookieBanner } from '../../../fixtures/staging-traps';
import type { ProductFamily } from '../../../config/platforms';

/** `/en/my-account/new-company` — create and publish form. */
export class NewCompanyPage {
  constructor(
    private readonly page: Page,
    private readonly product: ProductFamily = 'wlw',
  ) {}

  private formField(labelText: string): Locator {
    return this.page
      .locator('.vis-core-form-input')
      .filter({ has: this.page.locator('label', { hasText: labelText }) });
  }

  private inputByLabel(labelText: string): Locator {
    return this.formField(labelText).locator('input');
  }

  private buttonByLabel(labelText: string): Locator {
    return this.formField(labelText).locator('button');
  }

  async openNewCompany(): Promise<void> {
    // wlw staging often drops the session unless we hit `/` first so the cookie attaches.
    // ep does not need that hop.
    if (this.product === 'wlw') {
      await this.page.goto('/');
      await dismissCookieBanner(this.page);
    }
    await this.page.goto('/en/my-account/new-company');
    await dismissCookieBanner(this.page);
  }

  async fillCompanyName(name: string): Promise<void> {
    const input = this.inputByLabel('Company name');
    await expect(input).toBeVisible({ timeout: 15_000 });
    await input.clear();
    await input.fill(name);
  }

  async selectCountry(country: string): Promise<void> {
    await this.buttonByLabel('Country of company registration').click();
    await this.page.getByText(country, { exact: true }).click({ timeout: 15_000 });
  }

  async fillVatId(vatId: string): Promise<void> {
    await this.inputByLabel('VAT number').fill(vatId);
  }

  async fillAddress(street: string, additional: string, zip: string, city: string): Promise<void> {
    await this.inputByLabel('Street and number').fill(street);
    await expect(this.inputByLabel('Street and number')).toHaveValue(street);
    await this.inputByLabel('Address (optional)').fill(additional);
    await expect(this.inputByLabel('Address (optional)')).toHaveValue(additional);
    await this.inputByLabel('Postal code').fill(zip);
    await expect(this.inputByLabel('Postal code')).toHaveValue(zip);
    await this.inputByLabel('City').fill(city);
    await expect(this.inputByLabel('City')).toHaveValue(city);
  }

  async fillContactEmail(email: string): Promise<void> {
    await this.inputByLabel('Company email').fill(email);
  }

  async fillPhone(number: string): Promise<void> {
    const input = this.inputByLabel('Company phone number');
    await input.fill(number);
    await expect(input).toHaveValue(number.replace(/\s/g, ''));
  }

  async selectEmployeesCount(value: string): Promise<void> {
    const button = this.buttonByLabel('Number of employees');
    await button.click();
    await this.page.getByText(value, { exact: true }).click();
    await expect(button).toContainText(value);
  }

  async selectDeliveryArea(area: string): Promise<void> {
    const button = this.buttonByLabel('Delivery area');
    await button.click();
    await this.page.getByText(area, { exact: true }).click();
    await expect(button).toContainText(area);
  }

  async selectMainActivity(activity: string): Promise<void> {
    const container = this.page.locator('div.field-container[name="main_activities"]');
    const arrow = container.locator('svg.arrow');
    const menu = container.locator('ul.menu');
    const checkbox = menu.locator(`input#${activity}`);
    const optionLabel = menu.locator(`label[for="${activity}"]`);

    await arrow.click();
    await expect(menu).toBeVisible({ timeout: 15_000 });
    await optionLabel.click();
    await expect(checkbox).toBeChecked();
    await arrow.click();
    await expect(menu).toBeHidden({ timeout: 10_000 });
  }

  async selectBusinessSector(sector: string): Promise<void> {
    const button = this.buttonByLabel('Business sector');
    await button.click();
    await this.page.getByText(sector, { exact: true }).click();
    await expect(button).toContainText(sector);
  }

  async publishCompany(): Promise<void> {
    await this.page.getByRole('button', { name: 'Publish company profile' }).click();
    // Onboarding success modal after submit (`ps.onboarding_modal.button`).
    await this.page.getByRole('button', { name: /let['’]s go/i }).click();
  }
}
