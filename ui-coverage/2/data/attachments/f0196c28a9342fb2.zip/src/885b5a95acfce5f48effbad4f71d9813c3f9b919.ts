import type { APIRequestContext, Page } from '@playwright/test';
import type { ProductFamily } from '../../config/platforms';
import { companyEditorRegressionCopy } from '../../config/company-editor';
import { companyFormDefaults } from '../../config/company-form';
import { personaCredentials } from '../../config/load-platform-env';
import { loginPersonaViaApi } from '../../api/services/identity/flows/login-persona-api.flow';
import { createTestCompanyName, createTestContactEmail } from '../../fixtures/test-data';
import { CompanyProfilePage } from '../pages/company/company-profile.page';
import {
  fillAndPublishNewCompanyForm,
  openNewCompanyWithAccount,
} from './create-and-publish-company.flow';

/** Supplier session + brand-new published company on company editor (Cypress `before` hook parity). */
export async function prepareCompanyEditorRegression(
  page: Page,
  product: ProductFamily,
  apiRequest: APIRequestContext,
): Promise<{ companyName: string; contactEmail: string }> {
  await loginPersonaViaApi(apiRequest, product, 'supplier');
  const supplier = personaCredentials(product, 'supplier');
  await openNewCompanyWithAccount(page, product, supplier, apiRequest);

  const defaults = companyFormDefaults(product);
  const companyName = createTestCompanyName(defaults.companyNamePrefix);
  const contactEmail = createTestContactEmail();
  const regression = companyEditorRegressionCopy(product);

  await fillAndPublishNewCompanyForm(
    page,
    product,
    { companyName, contactEmail, defaults },
    { employeesCount: regression.employeesCount },
  );

  const profile = new CompanyProfilePage(page);
  await profile.navigateToCompanyProfile();

  return { companyName, contactEmail };
}
