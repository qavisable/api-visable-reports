/**
 * UI glue for new-company: session handoff vs the 12-field publish recipe (E2E).
 * Feature spec `publish-company.spec.ts` inlines the pages and asserts the heading.
 */
import { expect, type APIRequestContext, type Page } from '@playwright/test';
import type { CompanyFormDefaults } from '../../config/company-form';
import type { ProductFamily } from '../../config/platforms';
import { syncApiSessionToBrowser } from '../../fixtures/api-session';
import { CompanyProfilePage } from '../pages/company/company-profile.page';
import { NewCompanyPage } from '../pages/company/new-company.page';
import { LoginPage } from '../pages/login/login.page';

export type PublishCompanyProfileInput = {
  companyName: string;
  contactEmail: string;
  defaults: CompanyFormDefaults;
};

export type PublishCompanyFormOverrides = {
  employeesCount?: string;
};

export type NewCompanySessionResult = 'api-session' | 'ui-login' | 'already-authenticated';

/**
 * Land on new-company already authenticated.
 * Prefer API cookies. If the site sends us to /login (user is not a supplier yet),
 * start a clean login page — do not type into the leftover ?flow=&is_supplier=1 form.
 */
export async function openNewCompanyWithAccount(
  page: Page,
  product: ProductFamily,
  account: { email: string; password: string },
  apiRequest?: APIRequestContext,
): Promise<NewCompanySessionResult> {
  if (apiRequest) {
    await syncApiSessionToBrowser(apiRequest, page.context());
  }

  const newCompany = new NewCompanyPage(page, product);
  await newCompany.openNewCompany();

  if (!/\/login/.test(page.url())) {
    return apiRequest ? 'api-session' : 'already-authenticated';
  }

  const login = new LoginPage(page, product);
  await login.open();
  await login.signIn(account.email, account.password);
  await newCompany.openNewCompany();
  await expect(page).not.toHaveURL(/\/login/, { timeout: 20_000 });
  return 'ui-login';
}

/** Shared new-company form fills + publish (no navigation to editor). */
export async function fillAndPublishNewCompanyForm(
  page: Page,
  product: ProductFamily,
  input: PublishCompanyProfileInput,
  overrides: PublishCompanyFormOverrides = {},
): Promise<void> {
  const newCompany = new NewCompanyPage(page, product);
  const employeesCount = overrides.employeesCount ?? input.defaults.employeesCount;

  await newCompany.fillCompanyName(input.companyName);
  await newCompany.selectCountry(input.defaults.country);
  await newCompany.fillVatId(input.defaults.vatId);
  await newCompany.fillAddress(
    input.defaults.street,
    input.defaults.addressAdditional,
    input.defaults.postalCode,
    input.defaults.city,
  );
  await newCompany.fillContactEmail(input.contactEmail);
  await newCompany.fillPhone(input.defaults.phone);
  await newCompany.selectEmployeesCount(employeesCount);
  await newCompany.selectDeliveryArea('Regional');
  await newCompany.selectMainActivity('Distributor');
  await newCompany.selectBusinessSector('Accumulator and battery technology');
  await newCompany.publishCompany();
}

/** E2E only: the 12 new-company fills + publish. Feature spec `publish-company.spec.ts` inlines the pages instead. */
export async function createAndPublishCompanyProfile(
  page: Page,
  product: ProductFamily,
  input: PublishCompanyProfileInput,
  overrides: PublishCompanyFormOverrides = {},
): Promise<void> {
  await fillAndPublishNewCompanyForm(page, product, input, overrides);
  const profile = new CompanyProfilePage(page);
  await profile.navigateToCompanyProfile();
  await profile.expectProfileHeadingContains(input.defaults.nameFragment);
}
