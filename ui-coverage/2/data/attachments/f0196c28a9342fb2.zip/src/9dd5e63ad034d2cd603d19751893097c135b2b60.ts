/**
 * Regression: company editor tabs after publish (ported from Cypress
 * `business/company-profile/wlw-company-profile-editor-e2e.cy.ts`).
 * Serial suite — one new company, shared browser state (Cypress `testIsolation: false`).
 * Requires `SUPPLIER_*` per Playwright project (`.env.stage-wlw` / `.env.stage-ep`).
 */
import type { APIRequestContext, BrowserContext, Page } from '@playwright/test';
import { test } from '../../../fixtures';
import { companyEditorAssets, companyEditorRegressionCopy } from '../../../config/company-editor';
import {
  companyFormDefaults,
  companyPhoneCountryDial,
  companyPhoneNational,
} from '../../../config/company-form';
import { bypassHeaders, hasSupplierCredentials, loadPlatformEnv, personaCredentials } from '../../../config/load-platform-env';
import { productFromProjectName, type ProductFamily } from '../../../config/platforms';
import { stagingBypassToken } from '../../../fixtures/secrets';
import { installStagingRouteStubs, suppressCookieBanner } from '../../../fixtures/staging-traps';
import { prepareCompanyEditorRegression } from '../../flows/prepare-company-editor-regression.flow';
import { CompanyEditorPage } from '../../pages/company/company-editor.page';

test.describe('Company profile editor — full onboarding journey', { tag: ['@regression', '@wlw', '@ep'] }, () => {
  test.describe.configure({ mode: 'serial' });

  let context: BrowserContext;
  let page: Page;
  let apiRequest: APIRequestContext;
  let product: ProductFamily;
  let supplierEmail: string;
  let regressionCopy: ReturnType<typeof companyEditorRegressionCopy>;

  test.beforeAll(async ({ browser, playwright }, testInfo) => {
    // Serial Cypress parity: one browser session for all tests. `publicPage` is per-test and would reset state;
    // we mirror `fixtures/index.ts` setup (bypass, cookie banner, route stubs) on a shared context instead.
    test.setTimeout(300_000);
    product = productFromProjectName(testInfo.project.name);
    regressionCopy = companyEditorRegressionCopy(product);
    test.skip(!stagingBypassToken(product), `STAGING_BYPASS_TOKEN missing in .env.stage-${product}`);
    test.skip(
      !hasSupplierCredentials(product),
      `SUPPLIER_EMAIL / SUPPLIER_PASSWORD missing in .env.stage-${product}`,
    );

    const { baseUrl } = loadPlatformEnv(product);
    context = await browser.newContext({
      baseURL: baseUrl,
      extraHTTPHeaders: bypassHeaders(product),
    });
    await suppressCookieBanner(context, baseUrl);
    await installStagingRouteStubs(context);
    page = await context.newPage();

    apiRequest = await playwright.request.newContext({
      baseURL: baseUrl,
      extraHTTPHeaders: bypassHeaders(product),
    });

    supplierEmail = personaCredentials(product, 'supplier').email;
    await prepareCompanyEditorRegression(page, product, apiRequest);
  });

  test.afterAll(async () => {
    await apiRequest?.dispose();
    await context?.close();
  });

  test('uploads the company logo', async () => {
    const editor = new CompanyEditorPage(page);
    await editor.uploadLogo(companyEditorAssets.logo);
  });

  test('displays basic info fields in edit mode', async () => {
    const defaults = companyFormDefaults(product);
    const phoneNational = companyPhoneNational(defaults.phone);
    const editor = new CompanyEditorPage(page);
    await editor.clickEditPen();
    await editor.expectBasicInfoFieldsInEditMode({
      street: defaults.street,
      addressAdditional: defaults.addressAdditional,
      postalCode: defaults.postalCode,
      city: defaults.city,
      phoneCountryDial: companyPhoneCountryDial(product),
      phoneNational,
      employeesCount: regressionCopy.employeesCount,
      mainActivity: 'Distributor',
      businessSector: 'Accumulator and battery technology',
      deliveryArea: 'Regional',
      supplierEmail,
    });
  });

  test('fills website, founding year, description, and saves', async () => {
    const editor = new CompanyEditorPage(page);
    await editor.fillWebsite(regressionCopy.website);
    await editor.fillFoundingYear(regressionCopy.foundingYear);
    await editor.fillDescription(regressionCopy.description);
    await editor.save();
  });

  test('persists basic info fields after save', async () => {
    const defaults = companyFormDefaults(product);
    const phoneNational = companyPhoneNational(defaults.phone);
    const editor = new CompanyEditorPage(page);
    await editor.clickEditPenAfterSave();
    await editor.expectBasicInfoFieldsInEditMode({
      street: defaults.street,
      addressAdditional: defaults.addressAdditional,
      postalCode: defaults.postalCode,
      city: defaults.city,
      phoneCountryDial: companyPhoneCountryDial(product),
      phoneNational,
      employeesCount: regressionCopy.employeesCount,
      mainActivity: 'Distributor',
      businessSector: 'Accumulator and battery technology',
      deliveryArea: 'Regional',
      supplierEmail,
    });
    await editor.save();
  });

  test('uploads images with captions and video link', async () => {
    const editor = new CompanyEditorPage(page);
    await editor.openImagesTab();
    await editor.uploadImage(0, companyEditorAssets.image1);
    await editor.fillImageCaption(0, regressionCopy.imageCaption1);
    await editor.uploadImage(1, companyEditorAssets.image2);
    await editor.fillImageCaption(1, regressionCopy.imageCaption2);
    await editor.fillVideoLink(regressionCopy.videoLink);
  });

  test('uploads document, video title, and certificate', async () => {
    const editor = new CompanyEditorPage(page);
    await editor.uploadDocument(companyEditorAssets.catalogue);
    await editor.fillDocumentTitle(regressionCopy.documentTitle);
    await editor.fillVideoTitle(regressionCopy.videoTitle);
    await editor.addCertificate(regressionCopy.certificateName);
    await editor.save();
  });

  test('persists images tab data after save', async () => {
    const editor = new CompanyEditorPage(page);
    await editor.expectImagesTabPersisted({
      caption: regressionCopy.imageCaption1,
      videoLink: regressionCopy.videoLink,
      documentTitle: regressionCopy.documentTitle,
      videoTitle: regressionCopy.videoTitle,
      certificateName: regressionCopy.certificateName,
    });
  });

  test('checks incoterms and payment methods, then verifies persistence', async () => {
    const editor = new CompanyEditorPage(page);
    await editor.openDeliveryPaymentTab();
    await editor.checkIncoterm(regressionCopy.incoterm);
    await editor.checkPaymentMethod(regressionCopy.paymentPayPal);
    await editor.checkPaymentMethod(regressionCopy.paymentOnAccount);
    await editor.save();
    await editor.expectIncotermChecked(regressionCopy.incoterm);
    await editor.expectPaymentMethodChecked(regressionCopy.paymentPayPal);
    await editor.expectPaymentMethodChecked(regressionCopy.paymentOnAccount);
  });
});
